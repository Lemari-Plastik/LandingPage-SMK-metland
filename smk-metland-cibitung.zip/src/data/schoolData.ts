export interface HeroSlide {
  id: number;
  titlePrefix: string;
  titleHighlight: string;
  subtitle: string;
  ctaText: string;
  ctaHref: string;
  placeholderLabel: string;
}

export interface NewsItem {
  id: string;
  category: string;
  categoryBadgeBg: string;
  cardBgTint: string;
  iconTint: string;
  labelTint: string;
  date: string;
  title: string;
  summary: string;
  author: string;
  readTime: string;
  content: string[];
}

export interface AgendaItem {
  id: string;
  day: string;
  month: string;
  fullDate: string;
  title: string;
  location: string;
  time: string;
  organizer: string;
  description: string;
}

export interface ProgramItem {
  id: string;
  title: string;
  shortDesc: string;
  iconBg: string;
  iconColor: string;
  iconType: 'globe' | 'book' | 'beaker';
  highlights: string[];
  curriculumFocus: string;
  careerProspects: string;
}

export interface AchievementItem {
  id: string;
  category: 'Siswa' | 'Guru' | 'Sekolah' | 'Ekstrakurikuler';
  year: string;
  level: string;
  title: string;
  winner: string;
  iconType: 'sparkles' | 'users' | 'building' | 'music';
  description: string;
}

export interface ExtracurricularItem {
  id: string;
  emoji: string;
  name: string;
  category: string;
  schedule: string;
  location: string;
  coach: string;
  description: string;
  achievements: string[];
}

export interface GalleryPhotoItem {
  id: string;
  badge: string;
  aspect: string;
  title: string;
  category: string;
  date: string;
  gradientClass: string;
  description: string;
}

export interface GalleryVideoItem {
  id: string;
  title: string;
  description: string;
  duration: string;
  date: string;
  category: string;
  highlights: string[];
}

export interface TeacherStaffItem {
  id: string;
  name: string;
  role: string;
  department: string;
  education: string;
  experience: string;
  quote: string;
}

export interface SpmbApplication {
  regNumber: string;
  fullName: string;
  nisn: string;
  originSchool: string;
  program: string;
  parentName: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
  status: 'Terverifikasi - Jadwal Tes Tersedia' | 'Menunggu Verifikasi Berkas' | 'Lulus Seleksi Tahap 1';
}

export const HERO_SLIDES: HeroSlide[] = [
  {
    id: 0,
    titlePrefix: 'Membangun Masa Depan',
    titleHighlight: 'Bangsa',
    subtitle:
      'Kurikulum berstandar internasional dengan fasilitas premium yang siap memaksimalkan potensi putra-putri Anda.',
    ctaText: 'Tentang Kami',
    ctaHref: '#profil',
    placeholderLabel: 'Hero Background Placeholder (1920 × 1080)',
  },
  {
    id: 1,
    titlePrefix: 'Inovasi Vokasi Berbasis',
    titleHighlight: 'Karakter',
    subtitle:
      'Mengintegrasikan penguasaan teknologi industri terdepan, pembelajaran bilingual, dan pembinaan akhlak mulia bagi setiap siswa.',
    ctaText: 'Program Unggulan',
    ctaHref: '#program',
    placeholderLabel: 'Campus Innovation Showcase Placeholder (1920 × 1080)',
  },
  {
    id: 2,
    titlePrefix: 'Siap Bersaing di Era',
    titleHighlight: 'Global',
    subtitle:
      'Didukung lebih dari 85 tenaga pendidik profesional dan laboratorium modern untuk mencetak lulusan siap kerja dan wirausaha.',
    ctaText: 'Daftar SPMB Online',
    ctaHref: '#spmb',
    placeholderLabel: 'Global Industry Partnership Placeholder (1920 × 1080)',
  },
];

export const NEWS_ITEMS: NewsItem[] = [
  {
    id: 'news-1',
    category: 'Prestasi',
    categoryBadgeBg: 'bg-teal-600',
    cardBgTint: 'bg-teal-50/70',
    iconTint: 'text-teal-300',
    labelTint: 'text-teal-700/70',
    date: '01 Mei 2026',
    title: 'Siswa SMK Metland Cibitung Raih Medali Emas Olimpiade Matematika Tingkat Nasional 2026',
    summary:
      'SMK Metland Cibitung kembali mengukir prestasi membanggakan. Siswa kami berhasil meraih medali emas dalam kompetisi sains bergengsi tingkat nasional.',
    author: 'Tim Humas SMK Metland Cibitung',
    readTime: '3 menit baca',
    content: [
      'CIBITUNG — SMK Metland Cibitung kembali mengukir prestasi membanggakan di kancah nasional. Muhammad Rafli, siswa kelas XI, berhasil meraih Medali Emas dalam ajang Olimpiade Sains Nasional bidang Matematika Terapan yang diselenggarakan di Jakarta pada akhir April 2026.',
      'Kompetisi tersebut diikuti oleh lebih dari 450 perwakilan sekolah menengah dari 34 provinsi di seluruh Indonesia. Melalui pembinaan intensif dari klub STEM & Olimpiade sekolah, Rafli mampu menyelesaikan soal-soal pemodelan matematika dan pemecahan masalah tingkat lanjut dengan skor tertinggi.',
      'Kepala Sekolah SMK Metland Cibitung, Dr. Anonim, menyampaikan apresiasi setinggi-tingginya kepada siswa dan guru pembimbing atas dedikasi serta kerja keras yang konsisten. Prestasi ini diharapkan menjadi motivasi bagi seluruh siswa untuk terus berprestasi baik di bidang akademik maupun non-akademik.',
    ],
  },
  {
    id: 'news-2',
    category: 'Kegiatan Siswa',
    categoryBadgeBg: 'bg-cyan-700',
    cardBgTint: 'bg-cyan-50/70',
    iconTint: 'text-cyan-300',
    labelTint: 'text-cyan-800/70',
    date: '28 Apr 2026',
    title: 'Peresmian Laboratorium Robotik dan AI Terbaru oleh Dinas Pendidikan DKI...',
    summary:
      'Laboratorium robotik dan kecerdasan buatan kini hadir untuk mendukung inovasi siswa dalam menyongsong era revolusi industri terdepan.',
    author: 'Redaksi Jurnalistik Siswa',
    readTime: '4 menit baca',
    content: [
      'CIBITUNG — Guna menunjang penguasaan teknologi masa depan, SMK Metland Cibitung resmi mengoperasikan Laboratorium Robotik dan Kecerdasan Buatan (Artificial Intelligence) generasi terbaru pada tanggal 28 April 2026.',
      'Laboratorium ini dilengkapi dengan perangkat mikrokontroler industri, lengan robotik presisi, sensor IoT, serta workstation komputasi performa tinggi untuk pelatihan machine learning dan computer vision bagi siswa lintas jurusan.',
      'Melalui fasilitas baru ini, siswa dapat merancang purwarupa otomasi pintar secara langsung di bawah bimbingan praktisi industri dan guru produktif bersertifikat internasional.',
    ],
  },
  {
    id: 'news-3',
    category: 'Pengumuman',
    categoryBadgeBg: 'bg-teal-700',
    cardBgTint: 'bg-teal-50/70',
    iconTint: 'text-teal-300',
    labelTint: 'text-teal-700/70',
    date: '19 Apr 2026',
    title: 'Kunjungan Industri dan Penandatanganan MoU Bersama 12 Perusahaan Multinasional',
    summary:
      'Memperluas peluang magang dan penyerapan lulusan, SMK Metland Cibitung menjalin kemitraan strategis dengan belasan mitra industri terkemuka.',
    author: 'Bursa Kerja Khusus (BKK)',
    readTime: '3 menit baca',
    content: [
      'CIBITUNG — SMK Metland Cibitung terus memperkuat ekosistem link-and-match antara pendidikan vokasi dan dunia usaha/dunia industri (DUDI). Sebanyak 12 perusahaan multinasional menandatangani nota kesepahaman (MoU) penyelarasan kurikulum dan program Praktik Kerja Lapangan (PKL).',
      'Kemitraan ini mencakup program kelas industri, sertifikasi kompetensi berstandar global, serta jalur rekrutmen khusus bagi lulusan berprestasi SMK Metland Cibitung.',
    ],
  },
  {
    id: 'news-4',
    category: 'Akademik',
    categoryBadgeBg: 'bg-cyan-700',
    cardBgTint: 'bg-cyan-50/70',
    iconTint: 'text-cyan-300',
    labelTint: 'text-cyan-800/70',
    date: '10 Apr 2026',
    title: 'Wisuda Tahfidz Al-Qur’an Angkatan ke-8: 64 Siswa Capai Target Hafalan Mutqin',
    summary:
      'Komitmen Excellence with Character diwujudkan melalui keberhasilan 64 siswa menyelesaikan ujian sertifikasi hafalan Al-Qur’an dengan predikat Mumtaz.',
    author: 'Koordinator Keagamaan & Karakter',
    readTime: '3 menit baca',
    content: [
      'CIBITUNG — Suasana haru dan bangga menyelimuti Aula Utama SMK Metland Cibitung dalam gelaran Wisuda Tahfidz Al-Qur’an Angkatan ke-8. Sebanyak 64 siswa berhasil melewati tahapan tasmi’ dan uji publik hafalan dengan predikat sangat memuaskan.',
      'Program Tahfidz Al-Qur’an merupakan salah satu program unggulan sekolah yang membekali siswa dengan keseimbangan kecerdasan intelektual, keahlian vokasi, serta keteguhan spiritual.',
    ],
  },
];

export const AGENDA_ITEMS: AgendaItem[] = [
  {
    id: 'agenda-1',
    day: '13',
    month: 'Agu',
    fullDate: '13 Agustus 2026',
    title: 'Upacara Peringatan Hari Pendidikan',
    location: 'Lapangan Utama Sekolah',
    time: 'Pkl. 07.15 - Selesai',
    organizer: 'Kesiswaan & OSIS',
    description:
      'Upacara bendera bersama seluruh civitas akademika SMK Metland Cibitung disertai pemberian penghargaan bagi siswa dan guru berprestasi semester genap.',
  },
  {
    id: 'agenda-2',
    day: '03',
    month: 'Agu',
    fullDate: '03 Agustus 2026',
    title: 'Sosialisasi Program Pertukaran Siswa',
    location: 'Aula Serbaguna',
    time: 'Pkl. 09.00 WIB',
    organizer: 'Divisi Kerjasama Internasional & Program Bilingual',
    description:
      'Sesi informasi dan seleksi awal program pertukaran pelajar ke Jepang, Singapura, dan Jerman bagi siswa kelas X dan XI beserta orang tua/wali murid.',
  },
  {
    id: 'agenda-3',
    day: '29',
    month: 'Jul',
    fullDate: '29 Juli 2026',
    title: 'Pekan Olahraga Antar Kelas (Classmeeting)',
    location: 'Lapangan Olahraga Sekolah',
    time: 'Pkl. 08.00 WIB',
    organizer: 'OSIS & Seksi Olahraga',
    description:
      'Kompetisi futsal, basket, badminton, dan e-sport edukatif antar rombongan belajar untuk mempererat sportivitas dan kekompakan siswa.',
  },
  {
    id: 'agenda-4',
    day: '24',
    month: 'Jul',
    fullDate: '24 Juli 2026',
    title: 'Pelatihan Jurnalistik untuk Siswa',
    location: 'Perpustakaan Digital',
    time: 'Pkl. 10.00 WIB',
    organizer: 'Ekstrakurikuler Jurnalistik & Media Sekolah',
    description:
      'Workshop penulisan berita populer, fotografi jurnalistik, dan produksi konten media digital bersama praktisi media nasional.',
  },
  {
    id: 'agenda-5',
    day: '15',
    month: 'Agu',
    fullDate: '15 Agustus 2026',
    title: 'Expo Karya Inovasi STEM & Robotik 2026',
    location: 'Hall Inovasi & Lab Robotik',
    time: 'Pkl. 08.30 - 15.00 WIB',
    organizer: 'Jurusan Teknologi & Klub Robotik',
    description:
      'Pameran terbuka proyek IoT, otomasi industri, dan aplikasi cerdas karya siswa SMK Metland Cibitung yang dihadiri mitra industri dan masyarakat umum.',
  },
];

export const FEATURED_PROGRAMS: ProgramItem[] = [
  {
    id: 'prog-bilingual',
    title: 'Program Bilingual',
    shortDesc:
      'Pembelajaran dwibahasa (Indonesia-Inggris) untuk mempersiapkan siswa menghadapi era globalisasi.',
    iconBg: 'bg-teal-50',
    iconColor: 'text-teal-600',
    iconType: 'globe',
    highlights: [
      'Pengantar mata pelajaran produktif & sains dalam Bahasa Inggris aktif',
      'Sertifikasi TOEIC / IELTS Preparation terintegrasi kurikulum',
      'Kelas kolaborasi internasional & kesempatan pertukaran pelajar',
    ],
    curriculumFocus: 'Komunikasi bisnis global, presentasi teknis dwibahasa, dan literasi internasional.',
    careerProspects: 'Perusahaan multinasional, perhotelan & pariwisata global, serta beasiswa studi luar negeri.',
  },
  {
    id: 'prog-tahfidz',
    title: "Tahfidz Al-Qur'an",
    shortDesc:
      "Program hafalan Al-Qur'an intensif dengan metode mutqin dan bimbingan ustadz/ustadzah bersertifikat.",
    iconBg: 'bg-cyan-50',
    iconColor: 'text-cyan-600',
    iconType: 'book',
    highlights: [
      'Halaqah harian pagi & sore dengan rasio pembimbing ideal',
      'Tahsin bacaan bersanad dan metode murajaah terjadwal',
      'Wisuda Tahfidz tahunan dan sertifikasi capaian juz',
    ],
    curriculumFocus: 'Pembentukan karakter mulia, adab keilmuan, dan keteguhan hafalan Al-Qur’an.',
    careerProspects: 'Pemimpin berintegritas tinggi, jalur beasiswa khusus tahfidz di perguruan tinggi negeri & swasta.',
  },
  {
    id: 'prog-stem',
    title: 'STEM & Robotik',
    shortDesc:
      'Lab komputer modern dan program robotik untuk menumbuhkan minat teknologi dan berpikir komputasional.',
    iconBg: 'bg-teal-50',
    iconColor: 'text-teal-600',
    iconType: 'beaker',
    highlights: [
      'Praktikum IoT, mikrokontroler, dan pemrograman AI terapan',
      'Pembinaan intensif olimpiade sains dan kompetisi robotik nasional',
      'Proyek kolaborasi riset terapan bersama praktisi industri',
    ],
    curriculumFocus: 'Computational thinking, rekayasa perangkat lunak/keras, dan otomasi industri 4.0.',
    careerProspects: 'Software engineer, spesialis otomasi & IoT, teknisi robotik, dan technopreneur.',
  },
];

export const ACHIEVEMENT_ITEMS: AchievementItem[] = [
  {
    id: 'ach-1',
    category: 'Siswa',
    year: '2026',
    level: 'Tingkat Nasional',
    title: 'Juara 1 Olimpiade Sains Nasional (Matematika)',
    winner: 'Muhammad Rafli',
    iconType: 'sparkles',
    description:
      'Meraih medali emas dan skor tertinggi pada kompetisi Olimpiade Sains Nasional bidang Matematika Terapan tahun 2026 yang diikuti ratusan peserta dari seluruh provinsi.',
  },
  {
    id: 'ach-2',
    category: 'Guru',
    year: '2026',
    level: 'Tingkat Provinsi',
    title: 'Guru Inspiratif Tingkat Provinsi',
    winner: 'Bambang Irawan, S.Kom.',
    iconType: 'users',
    description:
      'Penghargaan atas inovasi media pembelajaran berbasis kecerdasan buatan dan dedikasi dalam membimbing riset teknologi siswa SMK Metland Cibitung.',
  },
  {
    id: 'ach-3',
    category: 'Sekolah',
    year: '2025',
    level: 'Tingkat Nasional',
    title: 'Sekolah Adiwiyata Mandiri',
    winner: 'Sekolah Berbudaya Lingkungan',
    iconType: 'building',
    description:
      'Penghargaan tertinggi dari Kementerian Lingkungan Hidup atas tata kelola kampus hijau, pengolahan limbah terpadu, dan kurikulum berwawasan lingkungan.',
  },
  {
    id: 'ach-4',
    category: 'Ekstrakurikuler',
    year: '2026',
    level: 'Tingkat Provinsi',
    title: 'Juara 1 Lomba Tari Kreasi Nusantara',
    winner: 'Tim Tari Tradisional',
    iconType: 'music',
    description:
      'Menampilkan koreografi tari kreasi nusantara terbaik pada Festival dan Lomba Seni Siswa Nasional (FLS2N) tingkat Provinsi Jawa Barat.',
  },
  {
    id: 'ach-5',
    category: 'Siswa',
    year: '2025',
    level: 'Tingkat Nasional',
    title: 'Juara 1 Lomba Kompetensi Siswa (LKS) Bidang IT Software',
    winner: 'Nadia Putri Lestari',
    iconType: 'sparkles',
    description:
      'Berhasil merancang sistem informasi enterprise dengan performa dan keamanan terbaik pada ajang LKS SMK Tingkat Nasional.',
  },
  {
    id: 'ach-6',
    category: 'Ekstrakurikuler',
    year: '2025',
    level: 'Tingkat Nasional',
    title: 'Best Design & Innovation Kontes Robot Nusantara',
    winner: 'Tim Metland Robotics',
    iconType: 'sparkles',
    description:
      'Memperoleh penghargaan desain mekanik dan algoritma navigasi otonom terbaik pada kejuaraan robotik pelajar tingkat nasional.',
  },
];

export const EXTRACURRICULAR_ITEMS: ExtracurricularItem[] = [
  {
    id: 'eks-1',
    emoji: '⚽',
    name: 'Sepak Bola',
    category: 'Olahraga',
    schedule: 'Selasa & Jumat, Pkl. 15.30 - 17.30 WIB',
    location: 'Lapangan Utama SMK Metland Cibitung',
    coach: 'Coach Hendra Wijaya, S.Pd.',
    description:
      'Membina fisik, taktik permainan tim, dan sportivitas melalui latihan rutin serta partisipasi aktif di Liga Pelajar Kabupaten & Provinsi.',
    achievements: ['Juara 1 Liga Futsal & Mini Soccer Pelajar Bekasi 2025', 'Semifinalis Piala Gubernur Jawa Barat 2025'],
  },
  {
    id: 'eks-2',
    emoji: '🏀',
    name: 'Basket',
    category: 'Olahraga',
    schedule: 'Rabu & Sabtu, Pkl. 15.30 - 17.30 WIB',
    location: 'Lapangan Indoor Sport Center',
    coach: 'Coach Kevin Pratama',
    description:
      'Program pembinaan bola basket putra dan putri dengan fokus pada fundamental, kerjasama tim, dan persiapan turnamen DBL/Student League.',
    achievements: ['Juara 2 Turnamen Basket Antar SMK/SMA Se-Jabodetabek 2025'],
  },
  {
    id: 'eks-3',
    emoji: '🏸',
    name: 'Badminton',
    category: 'Olahraga',
    schedule: 'Kamis & Sabtu, Pkl. 15.00 - 17.00 WIB',
    location: 'Aula Serbaguna (3 Lapangan Badminton)',
    coach: 'Bpk. Taufik Hidayatullah, M.Or.',
    description:
      'Mengembangkan ketangkasan, stamina, dan teknik bulu tangkis bagi siswa pemula maupun atlet sekolah.',
    achievements: ['Medali Emas Ganda Putra O2SN Tingkat Kabupaten 2025'],
  },
  {
    id: 'eks-4',
    emoji: '🎨',
    name: 'Seni Rupa',
    category: 'Seni & Kreativitas',
    schedule: 'Rabu, Pkl. 15.00 - 17.00 WIB',
    location: 'Studio Kreatif & Desain',
    coach: 'Ibu Larasati Dewi, S.Sn.',
    description:
      'Wadah eksplorasi seni lukis, ilustrasi digital, mural, dan kriya modern untuk mengasah kepekaan estetika siswa.',
    achievements: ['Pameran Tunggal Karya Siswa "Warna Masa Depan" 2025', 'Juara 1 Desain Poster Digital FLS2N 2025'],
  },
  {
    id: 'eks-5',
    emoji: '🎵',
    name: 'Paduan Suara',
    category: 'Seni & Musik',
    schedule: 'Selasa & Kamis, Pkl. 15.00 - 17.00 WIB',
    location: 'Ruang Musik & Auditorium',
    coach: 'Ibu Clara Simanjuntak, S.Mus.',
    description:
      'Melatih olah vokal, harmonisasi suara, dan repertoar lagu nasional, daerah, serta internasional untuk acara resmi maupun kompetisi.',
    achievements: ['Gold Medal Folklore Category Choir Festival 2025'],
  },
  {
    id: 'eks-6',
    emoji: '🎭',
    name: 'Teater',
    category: 'Seni Pertunjukan',
    schedule: 'Jumat, Pkl. 15.00 - 17.00 WIB',
    location: 'Amphitheater & Aula Serbaguna',
    coach: 'Bpk. Reza Rahadian Putra, S.Sn.',
    description:
      'Mengasah kepercayaan diri, seni peran, penulisan naskah, dan tata panggung melalui pementasan drama musikal dan teater modern.',
    achievements: ['Penyaji Terbaik Festival Drama Pelajar Jawa Barat 2025'],
  },
  {
    id: 'eks-7',
    emoji: '🤖',
    name: 'Robotik & IoT',
    category: 'Sains & Teknologi',
    schedule: 'Senin & Kamis, Pkl. 15.30 - 17.30 WIB',
    location: 'Laboratorium Robotik & AI',
    coach: 'Bambang Irawan, S.Kom.',
    description:
      'Riset dan perakitan robot line follower, drone, serta perangkat Internet of Things untuk kompetisi nasional.',
    achievements: ['Best Innovation Kontes Robot Nusantara 2025'],
  },
  {
    id: 'eks-8',
    emoji: '🇬🇧',
    name: 'English Debate Club',
    category: 'Akademik & Bahasa',
    schedule: 'Selasa, Pkl. 15.00 - 17.00 WIB',
    location: 'Language Center Lab',
    coach: 'Ms. Nadia Safitri, M.Pd.',
    description:
      'Meningkatkan kemampuan public speaking, critical thinking, dan debat parlemen bahasa Inggris (LDBI/NSDC).',
    achievements: ['Best Speaker National Schools Debating Championship Regional 2025'],
  },
  {
    id: 'eks-9',
    emoji: '📸',
    name: 'Jurnalistik & Sinematografi',
    category: 'Media & Komunikasi',
    schedule: 'Rabu, Pkl. 15.30 - 17.30 WIB',
    location: 'Multimedia Broadcast Studio',
    coach: 'Bpk. Dimas Anggara, S.I.Kom.',
    description:
      'Pelatihan produksi film pendek, fotografi dokumentasi, podcast sekolah, dan pengelolaan majalah digital.',
    achievements: ['Juara 1 Film Pendek Edukasi Pelajar Tingkat Provinsi 2025'],
  },
  {
    id: 'eks-10',
    emoji: '🕌',
    name: 'Rohis & Hadroh',
    category: 'Keagamaan & Karakter',
    schedule: 'Jumat, Pkl. 13.30 - 15.00 WIB',
    location: 'Masjid Kampus SMK Metland Cibitung',
    coach: 'Ustadz H. Fauzan Azima, Lc.',
    description:
      'Kegiatan kajian keislaman remaja, seni musik hadroh, serta kepanitiaan sosial dan hari besar Islam.',
    achievements: ['Juara 1 Festival Hadroh Pelajar Se-Bekasi Raya 2025'],
  },
  {
    id: 'eks-11',
    emoji: '⚜️',
    name: 'Pramuka & Paskibra',
    category: 'Kepemimpinan & Bela Negara',
    schedule: 'Sabtu, Pkl. 08.00 - 11.30 WIB',
    location: 'Lapangan Utama Sekolah',
    coach: 'Bpk. Surya Darmawan, S.Pd.',
    description:
      'Membentuk kedisiplinan, jiwa kepemimpinan, ketangkasan baris-berbaris, dan kepedulian sosial.',
    achievements: ['Juara Umum LKBB Variasi Formasi Tingkat Provinsi 2025'],
  },
  {
    id: 'eks-12',
    emoji: '🌱',
    name: 'Green School Club',
    category: 'Lingkungan & Sains',
    schedule: 'Kamis, Pkl. 15.00 - 16.30 WIB',
    location: 'Greenhouse & Taman Hidroponik',
    coach: 'Ibu Rina Kusuma, M.Si.',
    description:
      'Pengelolaan kebun hidroponik pintar, bank sampah sekolah, dan kampanye konservasi energi.',
    achievements: ['Kontributor Utama Penghargaan Sekolah Adiwiyata Mandiri 2025'],
  },
];

export const GALLERY_PHOTOS: GalleryPhotoItem[] = [
  {
    id: 'gal-1',
    badge: 'Galeri 01',
    aspect: '3:4',
    title: 'Fasilitas Sekolah',
    category: 'Sarana & Prasarana',
    date: 'April 2026',
    gradientClass: 'from-teal-50 to-teal-100',
    description:
      'Gedung pembelajaran terpadu berstandar internasional yang dilengkapi ruang kelas ber-AC, smartboard interaktif, perpustakaan digital, dan laboratorium praktik modern.',
  },
  {
    id: 'gal-2',
    badge: 'Galeri 02',
    aspect: '3:4',
    title: 'Kegiatan Ekstrakurikuler',
    category: 'Pengembangan Diri',
    date: 'Maret 2026',
    gradientClass: 'from-cyan-50 to-teal-100',
    description:
      'Aktivitas kolaboratif siswa dalam berbagai kegiatan ekstrakurikuler olahraga, seni budaya, serta klub inovasi teknologi setiap pekan.',
  },
  {
    id: 'gal-3',
    badge: 'Galeri 03',
    aspect: '3:4',
    title: 'Wisuda Angkatan 2025',
    category: 'Seremonial & Kelulusan',
    date: 'Mei 2025',
    gradientClass: 'from-teal-50 to-teal-100',
    description:
      'Momen khidmat pelepasan dan pengukuhan lulusan SMK Metland Cibitung Angkatan 2025 yang dihadiri orang tua, mitra industri, dan jajaran pimpinan yayasan.',
  },
  {
    id: 'gal-4',
    badge: 'Galeri 04',
    aspect: '3:4',
    title: 'Kunjungan Industri & Edukasi',
    category: 'Kemitraan Industri',
    date: 'Februari 2026',
    gradientClass: 'from-cyan-50 to-teal-100',
    description:
      'pembelajaran lapangan secara langsung di fasilitas produksi perusahaan mitra untuk mengenal budaya kerja profesional dan standar keselamatan industri.',
  },
];

export const GALLERY_VIDEOS: GalleryVideoItem[] = [
  {
    id: 'vid-1',
    title: 'Profil Sekolah & Fasilitas Pembelajaran Modern',
    description:
      'Mengenal lebih dekat lingkungan sekolah, kurikulum unggulan, serta sarana prasarana penunjang prestasi siswa.',
    duration: '04:15',
    date: 'Mei 2026',
    category: 'Profil Resmi',
    highlights: [
      'Tur virtual ruang kelas pintar & perpustakaan digital',
      'Wawancara Kepala Sekolah & testimoni mitra industri',
      'Cuplikan suasana belajar Program Bilingual, Tahfidz, dan STEM',
    ],
  },
  {
    id: 'vid-2',
    title: 'Keseruan Kegiatan Ekstrakurikuler & Eksplorasi Bakat',
    description:
      'Dokumentasi berbagai cabang ekstrakurikuler mulai dari robotik, seni musik, olahraga, hingga kepanduan.',
    duration: '03:40',
    date: 'April 2026',
    category: 'Kehidupan Siswa',
    highlights: [
      'Latihan tim basket, sepak bola, dan badminton di Sport Center',
      'Eksperimen robot otonom di Laboratorium AI',
      'Penampilan paduan suara dan tari tradisional nusantara',
    ],
  },
  {
    id: 'vid-3',
    title: 'Peringatan Hari Kemerdekaan & Pentas Seni Siswa',
    description:
      'Keriaan upacara bendera dan penampilan kreasi tari serta musik kreasi karya siswa.',
    duration: '05:20',
    date: 'Agustus 2025',
    category: 'Event Tahunan',
    highlights: [
      'Formasi Paskibra SMK Metland Cibitung pada upacara bendera',
      'Parade kostum budaya nusantara antar kelas',
      'Panggung apresiasi seni musik dan teater siswa',
    ],
  },
  {
    id: 'vid-4',
    title: 'Pameran Karya Inovasi & Prestasi Juara Nasional',
    description:
      'Untuk karya teknologi sains dan penghargaan bergengsi yang berhasil diraih siswa/siswi.',
    duration: '04:50',
    date: 'Maret 2026',
    category: 'Prestasi & Inovasi',
    highlights: [
      'Demo purwarupa smart home & otomasi industri karya siswa',
      'Liputan persiapan tim Olimpiade Sains Nasional',
      'Penyerahan penghargaan juara nasional dan beasiswa prestasi',
    ],
  },
];

export const TEACHERS_AND_STAFF: TeacherStaffItem[] = [
  {
    id: 'st-1',
    name: 'Dr. Anonim',
    role: 'Kepala Sekolah',
    department: 'Manajemen Pimpinan',
    education: 'S3 Manajemen Pendidikan',
    experience: '20+ Tahun Pengalaman Akademik & Vokasi',
    quote: 'Pendidikan adalah investasi terbaik untuk masa depan bangsa yang berkarakter.',
  },
  {
    id: 'st-2',
    name: 'Bambang Irawan, S.Kom., M.T.',
    role: 'Kepala Program STEM & Robotik',
    department: 'Teknologi Informasi & Rekayasa',
    education: 'S2 Teknik Elektro & Informatika',
    experience: '12 Tahun (Peraih Guru Inspiratif Tingkat Provinsi 2026)',
    quote: 'Membimbing siswa menjadi pencipta teknologi, bukan sekadar pengguna.',
  },
  {
    id: 'st-3',
    name: 'Ms. Nadia Safitri, M.Pd.',
    role: 'Koordinator Program Bilingual',
    department: 'Bahasa & Kerjasama Internasional',
    education: 'S2 Pendidikan Bahasa Inggris',
    experience: '10 Tahun Pengalaman Kurikulum Internasional',
    quote: 'Penguasaan bahasa asing membuka pintu kolaborasi tanpa batas di tingkat global.',
  },
  {
    id: 'st-4',
    name: 'Ustadz H. Fauzan Azima, Lc., M.A.',
    role: 'Koordinator Tahfidz & Pembinaan Karakter',
    department: 'Pendidikan Agama & Karakter',
    education: 'S2 Studi Islam & Al-Qur’an',
    experience: '14 Tahun Pembinaan Tahfidz Bersanad',
    quote: 'Kecerdasan intelektual harus senantiasa berjalan beriringan dengan kemuliaan akhlak.',
  },
  {
    id: 'st-5',
    name: 'Ir. Hendra Kusuma, M.M.',
    role: 'Wakil Kepala Sekolah Bidang Hubungan Industri',
    department: 'Kemitraan DUDI & BKK',
    education: 'S2 Manajemen Industri',
    experience: '16 Tahun Praktisi & Akademisi Industri',
    quote: 'Menjembatani kompetensi siswa dengan standar nyata dunia industri modern.',
  },
  {
    id: 'st-6',
    name: 'Dra. Siti Nurhaliza, M.Pd.',
    role: 'Wakil Kepala Sekolah Bidang Kurikulum',
    department: 'Pengembangan Akademik',
    education: 'S2 Teknologi Pembelajaran',
    experience: '18 Tahun Pengembangan Kurikulum Vokasi',
    quote: 'Kurikulum adaptif yang berpusat pada potensi unik setiap peserta didik.',
  },
];

export const INITIAL_SPMB_APPLICATIONS: SpmbApplication[] = [
  {
    regNumber: 'SPMB-2026-1042',
    fullName: 'Rizky Pratama Putra',
    nisn: '0098451234',
    originSchool: 'SMP Negeri 1 Cibitung',
    program: 'STEM & Robotik',
    parentName: 'Budi Santoso',
    phone: '081288990011',
    email: 'rizky.pratama@example.com',
    address: 'Perumahan Metland Cibitung Cluster Taman Sakura, Bekasi',
    createdAt: '02 Mei 2026',
    status: 'Lulus Seleksi Tahap 1',
  },
  {
    regNumber: 'SPMB-2026-1088',
    fullName: 'Aisyah Zahra Kamila',
    nisn: '0097112233',
    originSchool: 'SMP Islam Terpadu Al-Fityan',
    program: 'Program Bilingual',
    parentName: 'H. Ahmad Hidayat',
    phone: '081377665544',
    email: 'aisyah.zahra@example.com',
    address: 'Jl. Raya Cikarang - Cibitung No. 45, Bekasi',
    createdAt: '05 Mei 2026',
    status: 'Terverifikasi - Jadwal Tes Tersedia',
  },
];
