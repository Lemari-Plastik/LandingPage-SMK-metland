/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  HERO_SLIDES,
  NEWS_ITEMS,
  AGENDA_ITEMS,
  FEATURED_PROGRAMS,
  ACHIEVEMENT_ITEMS,
  EXTRACURRICULAR_ITEMS,
  GALLERY_PHOTOS,
  GALLERY_VIDEOS,
  TEACHERS_AND_STAFF,
  INITIAL_SPMB_APPLICATIONS,
  SpmbApplication,
} from './data/schoolData';
import { PortalModals, ActiveModal } from './components/PortalModals';

const SPMB_STORAGE_KEY = 'smk_metland_cibitung_spmb_2026';

export default function App() {
  const [activeSlide, setActiveSlide] = useState<number>(0);
  const [newsOffset, setNewsOffset] = useState<number>(0);
  const [ekskulPage, setEkskulPage] = useState<number>(0);
  const [activeNav, setActiveNav] = useState<string>('#beranda');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [modal, setModal] = useState<ActiveModal>({ type: 'none' });

  const [spmbApplications, setSpmbApplications] = useState<SpmbApplication[]>(() => {
    try {
      const saved = localStorage.getItem(SPMB_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback to initial seeded applications
    }
    return INITIAL_SPMB_APPLICATIONS;
  });

  useEffect(() => {
    try {
      localStorage.setItem(SPMB_STORAGE_KEY, JSON.stringify(spmbApplications));
    } catch {
      // Ignore storage quota errors
    }
  }, [spmbApplications]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setModal({ type: 'none' });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleAddSpmbApplication = (newApp: SpmbApplication) => {
    setSpmbApplications((prev) => [newApp, ...prev]);
  };

  const handlePrevNews = () => {
    setNewsOffset((prev) => (prev === 0 ? Math.max(0, NEWS_ITEMS.length - 2) : prev - 2));
  };

  const handleNextNews = () => {
    setNewsOffset((prev) => (prev + 2 >= NEWS_ITEMS.length ? 0 : prev + 2));
  };

  const visibleNews = NEWS_ITEMS.slice(newsOffset, newsOffset + 2);

  const handlePrevEkskul = () => {
    setEkskulPage((prev) => (prev === 0 ? 1 : 0));
  };

  const handleNextEkskul = () => {
    setEkskulPage((prev) => (prev === 1 ? 0 : 1));
  };

  const visibleEkskul = EXTRACURRICULAR_ITEMS.slice(ekskulPage * 6, ekskulPage * 6 + 6);
  const currentHero = HERO_SLIDES[activeSlide];

  const scrollToSection = (href: string) => {
    setActiveNav(href);
    setMobileMenuOpen(false);
    const id = href.replace('#', '');
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-slate-800 antialiased selection:bg-teal-600 selection:text-white">
      {/* BEGIN: TopHeaderNavigation */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-teal-100/70 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-8 h-20">
            {/* Brand Logo Area */}
            <a
              className="flex items-center gap-3 group shrink-0"
              data-purpose="school-branding"
              href="#beranda"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#beranda');
              }}
            >
              <div className="w-11 h-11 rounded-full bg-teal-600 flex items-center justify-center text-white font-bold shadow-md shadow-teal-600/20 group-hover:bg-teal-700 transition shrink-0">
                <svg className="w-6 h-6 text-teal-100" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                </svg>
              </div>
              <div className="leading-tight">
                <span className="block font-bold text-base sm:text-lg text-slate-900 tracking-tight group-hover:text-teal-700 transition whitespace-nowrap">
                  SMK Metland Cibitung
                </span>
                <span className="block text-[11px] font-semibold text-teal-600 uppercase tracking-wider whitespace-nowrap">
                  Excellence with Character
                </span>
              </div>
            </a>

            {/* Main Desktop Navigation */}
            <nav
              className="hidden md:flex items-center space-x-7 text-sm font-medium text-slate-700"
              data-purpose="main-navigation"
            >
              {[
                { label: 'Beranda', href: '#beranda', isModal: false },
                { label: 'Profil Sekolah', href: '#profil', isModal: false },
                { label: 'Guru & Staff', href: '#guru', isModal: true },
                { label: 'Informasi', href: '#informasi', isModal: false },
                { label: 'Galeri', href: '#galeri', isModal: false },
                { label: 'Kontak', href: '#kontak', isModal: false },
              ].map((nav) => {
                const isActive = activeNav === nav.href;
                return (
                  <a
                    key={nav.href}
                    href={nav.href}
                    onClick={(e) => {
                      e.preventDefault();
                      if (nav.isModal) {
                        setModal({ type: 'guru-staff' });
                      } else {
                        scrollToSection(nav.href);
                      }
                    }}
                    className={`whitespace-nowrap shrink-0 pb-1 transition ${
                      isActive
                        ? 'text-teal-700 font-semibold border-b-2 border-teal-600'
                        : 'hover:text-teal-700'
                    }`}
                  >
                    {nav.label}
                  </a>
                );
              })}
            </nav>

            {/* CTA Action Button & Mobile Hamburger */}
            <div className="flex items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => setModal({ type: 'spmb', initialTab: 'register' })}
                className="hidden sm:inline-flex items-center justify-center px-4 py-2 rounded-full text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 shadow-sm transition whitespace-nowrap shrink-0 cursor-pointer"
              >
                Daftar Sekarang
              </button>
              <button
                type="button"
                onClick={() => setMobileMenuOpen((prev) => !prev)}
                className="md:hidden w-10 h-10 rounded-xl border border-teal-100 flex items-center justify-center text-teal-700 hover:bg-teal-50 transition"
                aria-label="Menu Navigasi"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  {mobileMenuOpen ? (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  ) : (
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                  )}
                </svg>
              </button>
            </div>
          </div>

          {/* Mobile Drawer */}
          {mobileMenuOpen && (
            <div className="md:hidden py-4 border-t border-teal-100 space-y-2">
              {[
                { label: 'Beranda', href: '#beranda', isModal: false },
                { label: 'Profil Sekolah', href: '#profil', isModal: false },
                { label: 'Guru & Staff', href: '#guru', isModal: true },
                { label: 'Informasi', href: '#informasi', isModal: false },
                { label: 'Galeri', href: '#galeri', isModal: false },
                { label: 'Kontak', href: '#kontak', isModal: false },
              ].map((nav) => (
                <a
                  key={nav.href}
                  href={nav.href}
                  onClick={(e) => {
                    e.preventDefault();
                    setMobileMenuOpen(false);
                    if (nav.isModal) {
                      setModal({ type: 'guru-staff' });
                    } else {
                      scrollToSection(nav.href);
                    }
                  }}
                  className="block px-3 py-2 rounded-xl text-sm font-medium text-slate-700 hover:bg-teal-50 hover:text-teal-700"
                >
                  {nav.label}
                </a>
              ))}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setMobileMenuOpen(false);
                    setModal({ type: 'spmb', initialTab: 'register' });
                  }}
                  className="w-full py-2.5 rounded-full text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 shadow-sm transition"
                >
                  Daftar Sekarang
                </button>
              </div>
            </div>
          )}
        </div>
      </header>
      {/* END: TopHeaderNavigation */}

      <main>
        {/* BEGIN: HeroSection */}
        <section
          className="relative min-h-[640px] lg:h-[720px] flex items-center justify-center bg-brand-darkTeal overflow-hidden"
          data-purpose="hero-banner"
          id="beranda"
        >
          {/* Background Graphic Placeholder */}
          <div className="absolute inset-0 z-0 bg-gradient-to-br from-cyan-950 via-teal-950 to-slate-950">
            <div className="w-full h-full flex flex-col items-center justify-center opacity-30 select-none">
              <svg
                className="w-28 h-28 text-teal-400 stroke-[1]"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="text-teal-200 text-xs font-semibold uppercase tracking-widest mt-3">
                {currentHero.placeholderLabel}
              </span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />
          </div>

          {/* Hero Content */}
          <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 text-center text-white py-16">
            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight mb-6 text-balance">
              {currentHero.titlePrefix}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-200 via-cyan-300 to-teal-100">
                {currentHero.titleHighlight}
              </span>
            </h1>
            {/* Subtitle */}
            <p className="text-base sm:text-lg lg:text-xl text-teal-50 max-w-2xl mx-auto font-normal leading-relaxed mb-8">
              {currentHero.subtitle}
            </p>
            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-4">
              <a
                className="inline-flex items-center gap-2 px-7 py-3 rounded-full text-slate-950 font-semibold bg-teal-400 hover:bg-teal-300 shadow-lg shadow-teal-500/25 transition duration-200 whitespace-nowrap"
                href={currentHero.ctaHref}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(currentHero.ctaHref);
                }}
              >
                {currentHero.ctaText}
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    d="M14 5l7 7m0 0l-7 7m7-7H3"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                  />
                </svg>
              </a>
            </div>
            {/* Carousel Indicators */}
            <div aria-label="Slide Indicator" className="flex items-center justify-center gap-2 mt-14">
              {HERO_SLIDES.map((slide, idx) => (
                <button
                  key={slide.id}
                  type="button"
                  aria-label={`Slide ${idx + 1}`}
                  onClick={() => setActiveSlide(idx)}
                  className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                    activeSlide === idx
                      ? 'w-8 bg-teal-400'
                      : 'w-2 bg-white/40 hover:bg-white'
                  }`}
                />
              ))}
            </div>
          </div>
        </section>
        {/* END: HeroSection */}

        {/* BEGIN: PrincipalWelcome */}
        <section
          className="py-20 bg-teal-50/40 border-b border-teal-100"
          data-purpose="principal-welcome"
          id="profil"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white rounded-3xl p-6 sm:p-10 lg:p-12 shadow-sm border border-teal-100/80 flex flex-col md:flex-row items-center gap-8 lg:gap-14">
              {/* Principal Portrait Placeholder */}
              <div className="w-full md:w-5/12 max-w-sm flex-shrink-0 relative">
                <div className="relative overflow-hidden rounded-2xl shadow-md aspect-[4/5] bg-gradient-to-b from-teal-50 to-teal-100/60 border-2 border-dashed border-teal-200 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-20 h-20 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center mb-3 shadow-inner">
                    <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="1.6"
                      />
                    </svg>
                  </div>
                  <span className="text-xs font-bold text-teal-800 uppercase tracking-wide">
                    Foto Kepala Sekolah
                  </span>
                  <span className="text-[11px] text-teal-600/80 mt-1">Placeholder Image (4:5)</span>
                  <div className="absolute bottom-4 left-4 right-4 text-center">
                    <button
                      type="button"
                      onClick={() => setModal({ type: 'guru-staff' })}
                      className="inline-block px-4 py-1.5 rounded-full text-xs font-semibold bg-teal-700 hover:bg-teal-800 text-white shadow-md transition cursor-pointer"
                    >
                      Kepala Sekolah
                    </button>
                  </div>
                </div>
              </div>

              {/* Principal Welcome Text */}
              <div className="w-full md:w-7/12">
                <div className="inline-block text-xs font-bold tracking-widest text-teal-700 uppercase mb-3">
                  Sambutan Kepala Sekolah
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 tracking-tight leading-snug mb-5 text-balance">
                  "Pendidikan Adalah Investasi Terbaik untuk Masa Depan"
                </h2>
                <p className="text-slate-600 text-sm sm:text-base leading-relaxed mb-6">
                  Selamat datang di SMK Metland Cibitung. Kami berkomitmen untuk menyajikan pendidikan vokasi unggul yang mengintegrasikan penguasaan teknologi terdepan, kecakapan industri praktis, serta pembentukan karakter luhur bagi setiap peserta didik kami agar mampu bersaing secara global.
                </p>
                <div className="border-t border-teal-100 pt-5 flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h3 className="font-bold text-slate-900 text-base sm:text-lg">Dr. Anonim</h3>
                    <p className="text-xs sm:text-sm text-teal-700 font-medium">
                      Kepala Sekolah SMK Metland Cibitung
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'guru-staff' })}
                    className="text-xs font-semibold text-teal-700 hover:text-teal-800 hover:underline cursor-pointer"
                  >
                    Lihat Profil Guru &amp; Staff →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* END: PrincipalWelcome */}

        {/* BEGIN: NewsAndAgendaSection */}
        <section className="py-20 bg-white" data-purpose="news-and-events" id="informasi">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Section Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-12 pb-4 border-b border-teal-100">
              <div>
                <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                  Informasi
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  Berita Terbaru
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  Kabar terkini seputar kegiatan, prestasi, dan pengumuman penting dari sekolah kami.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModal({ type: 'news-all' })}
                className="mt-4 sm:mt-0 text-xs sm:text-sm font-semibold text-slate-700 hover:text-teal-700 border border-teal-200 rounded-full px-4 py-2 hover:border-teal-600 transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                Lihat Semua Berita →
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: News Cards */}
              <div className="lg:col-span-8 space-y-6">
                <div className="text-xs text-slate-400 flex items-center justify-between">
                  <span>← Geser untuk melihat berita lainnya →</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={handlePrevNews}
                      aria-label="Berita sebelumnya"
                      className="w-8 h-8 rounded-full border border-teal-200 flex items-center justify-center text-teal-700 hover:bg-teal-50 transition cursor-pointer"
                    >
                      ←
                    </button>
                    <button
                      type="button"
                      onClick={handleNextNews}
                      aria-label="Berita selanjutnya"
                      className="w-8 h-8 rounded-full border border-teal-200 flex items-center justify-center text-teal-700 hover:bg-teal-50 transition cursor-pointer"
                    >
                      →
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {visibleNews.map((news) => (
                    <article
                      key={news.id}
                      onClick={() => setModal({ type: 'news-detail', item: news })}
                      className="bg-white rounded-2xl border border-teal-100 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col group cursor-pointer"
                    >
                      <div
                        className={`relative h-44 ${news.cardBgTint} border-b border-teal-100 flex flex-col items-center justify-center overflow-hidden`}
                      >
                        <span
                          className={`absolute top-3 left-3 ${news.categoryBadgeBg} text-white text-[11px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider z-10 shadow-sm`}
                        >
                          {news.category}
                        </span>
                        <svg
                          className={`w-12 h-12 ${news.iconTint} group-hover:scale-110 transition duration-300 mb-1`}
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Z"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="1.5"
                          />
                        </svg>
                        <span className={`text-[11px] font-medium ${news.labelTint}`}>
                          Thumbnail Berita (16:9)
                        </span>
                      </div>
                      <div className="p-5 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[11px] font-medium text-slate-400 block mb-2">
                            {news.date}
                          </span>
                          <h3 className="text-base font-bold text-slate-900 group-hover:text-teal-700 transition leading-snug mb-2">
                            {news.title}
                          </h3>
                          <p className="text-xs text-slate-600 line-clamp-3 mb-4">{news.summary}</p>
                        </div>
                        <span className="text-xs font-semibold text-teal-700 group-hover:underline inline-flex items-center gap-1">
                          Baca Selengkapnya →
                        </span>
                      </div>
                    </article>
                  ))}
                </div>
              </div>

              {/* Right Column: Agenda Sekolah */}
              <div className="lg:col-span-4 bg-teal-50/50 p-6 rounded-2xl border border-teal-100 flex flex-col justify-between">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-1">Agenda Sekolah</h3>
                  <p className="text-xs text-slate-500 mb-6">Jadwal kegiatan terdekat</p>
                  <div className="space-y-4">
                    {AGENDA_ITEMS.slice(0, 4).map((ag, idx) => (
                      <div
                        key={ag.id}
                        onClick={() => setModal({ type: 'agenda-detail', item: ag })}
                        className={`flex items-start gap-3.5 cursor-pointer group ${
                          idx < 3 ? 'pb-3 border-b border-teal-100' : ''
                        }`}
                      >
                        <div className="w-12 h-12 rounded-xl bg-teal-700 group-hover:bg-teal-600 transition text-white flex flex-col items-center justify-center flex-shrink-0 shadow-sm tabular-nums">
                          <span className="text-base font-bold leading-none">{ag.day}</span>
                          <span className="text-[9px] uppercase font-semibold">{ag.month}</span>
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 group-hover:text-teal-700 transition leading-snug">
                            {ag.title}
                          </h4>
                          <p className="text-[11px] text-slate-500 mt-0.5">• {ag.location}</p>
                          <p className="text-[10px] text-slate-400">{ag.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="pt-6 mt-6 border-t border-teal-200/80 text-center">
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'agenda-all' })}
                    className="text-xs font-semibold text-teal-700 hover:underline cursor-pointer"
                  >
                    Lihat Semua Agenda →
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* END: NewsAndAgendaSection */}

        {/* BEGIN: FeaturedPrograms */}
        <section className="py-20 bg-teal-50/40" data-purpose="featured-programs" id="program">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14">
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Keunggulan Kami
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Program Unggulan</h2>
              <p className="text-sm text-slate-500 mt-2">
                Program pendidikan terbaik yang dirancang untuk mengembangkan potensi siswa secara menyeluruh.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {FEATURED_PROGRAMS.map((prog) => (
                <div
                  key={prog.id}
                  onClick={() => setModal({ type: 'program-detail', item: prog })}
                  className="bg-white rounded-2xl p-8 border border-teal-100 shadow-sm hover:shadow-md hover:border-teal-300 transition text-center group cursor-pointer"
                >
                  <div
                    className={`w-14 h-14 mx-auto mb-6 rounded-2xl ${prog.iconBg} ${prog.iconColor} flex items-center justify-center group-hover:scale-110 transition duration-300 shadow-inner`}
                  >
                    {prog.iconType === 'globe' && (
                      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.8"
                        />
                      </svg>
                    )}
                    {prog.iconType === 'book' && (
                      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.8"
                        />
                      </svg>
                    )}
                    {prog.iconType === 'beaker' && (
                      <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          d="M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5M9.75 3.104c-.251.023-.501.05-.75.082m.75-.082a24.301 24.301 0 014.5 0m0 0v5.714c0 .597.237 1.17.659 1.591L19.8 15.3M14.25 3.104c.251.023.501.05.75.082M19.8 15.3l-1.57.942a4.5 4.5 0 01-4.46 0L12 15.158l-1.77 1.084a4.5 4.5 0 01-4.46 0L4.2 15.3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.8"
                        />
                      </svg>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition mb-2">
                    {prog.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{prog.shortDesc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
        {/* END: FeaturedPrograms */}

        {/* BEGIN: KeyMetricsStatsBar */}
        <section
          className="py-14 bg-gradient-to-r from-teal-800 via-teal-700 to-cyan-800 text-white shadow-inner"
          data-purpose="metrics-counter"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-y md:divide-y-0 md:divide-x divide-teal-600/50">
              {/* Stat 1 */}
              <div className="pt-4 md:pt-0">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-teal-900/40 mb-2 text-teal-200">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums">1,250+</div>
                <div className="text-xs uppercase tracking-wider text-teal-100 mt-1 font-semibold">
                  Total Siswa
                </div>
              </div>
              {/* Stat 2 */}
              <div className="pt-4 md:pt-0">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-teal-900/40 mb-2 text-teal-200">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M19 14l-7 7m0 0l-7-7m7 7V3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums">85+</div>
                <div className="text-xs uppercase tracking-wider text-teal-100 mt-1 font-semibold">
                  Tenaga Pendidik
                </div>
              </div>
              {/* Stat 3 */}
              <div className="pt-4 md:pt-0">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-teal-900/40 mb-2 text-teal-200">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums">28 Th</div>
                <div className="text-xs uppercase tracking-wider text-teal-100 mt-1 font-semibold">
                  Tahun Berdiri
                </div>
              </div>
              {/* Stat 4 */}
              <div className="pt-4 md:pt-0">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-teal-900/40 mb-2 text-teal-200">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      d="M4 6h16M4 10h16M4 14h16M4 18h16"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                    />
                  </svg>
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold tracking-tight tabular-nums">36</div>
                <div className="text-xs uppercase tracking-wider text-teal-100 mt-1 font-semibold">
                  Rombongan Belajar
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* END: KeyMetricsStatsBar */}

        {/* BEGIN: SchoolAchievements */}
        <section className="py-20 bg-white" data-purpose="school-achievements">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-12 pb-4 border-b border-teal-100">
              <div>
                <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                  Achievement Center
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  Prestasi Membanggakan
                </h2>
                <p className="text-sm text-slate-500 mt-1">
                  Bukti nyata komitmen kami dalam mencetak generasi unggul di berbagai bidang akademik maupun non-akademik.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setModal({ type: 'achievement-all' })}
                className="mt-4 sm:mt-0 text-xs sm:text-sm font-semibold text-slate-700 hover:text-teal-700 border border-teal-200 rounded-full px-4 py-2 hover:border-teal-600 transition flex items-center gap-1 whitespace-nowrap cursor-pointer"
              >
                Lihat Semua Prestasi →
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {ACHIEVEMENT_ITEMS.slice(0, 4).map((ach) => (
                <div
                  key={ach.id}
                  onClick={() => setModal({ type: 'achievement-detail', item: ach })}
                  className="bg-white rounded-2xl border border-teal-100 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col cursor-pointer group"
                >
                  <div className="h-44 bg-teal-50/50 flex flex-col items-center justify-center relative border-b border-teal-50">
                    <span className="absolute top-3 left-3 bg-white/90 backdrop-blur text-[10px] font-bold px-2 py-0.5 rounded text-teal-800">
                      {ach.category}
                    </span>
                    <span className="absolute bottom-3 right-3 bg-teal-600 text-white text-[10px] font-extrabold px-2 py-0.5 rounded tabular-nums">
                      {ach.year}
                    </span>
                    {ach.iconType === 'sparkles' && (
                      <svg
                        className="w-12 h-12 text-teal-300 group-hover:scale-110 transition mb-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.5"
                        />
                      </svg>
                    )}
                    {ach.iconType === 'users' && (
                      <svg
                        className="w-12 h-12 text-teal-300 group-hover:scale-110 transition mb-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.5"
                        />
                      </svg>
                    )}
                    {ach.iconType === 'building' && (
                      <svg
                        className="w-12 h-12 text-teal-300 group-hover:scale-110 transition mb-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.5"
                        />
                      </svg>
                    )}
                    {ach.iconType === 'music' && (
                      <svg
                        className="w-12 h-12 text-teal-300 group-hover:scale-110 transition mb-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="1.5"
                        />
                      </svg>
                    )}
                    <span className="text-[10px] text-teal-600/70 font-medium">
                      Foto Prestasi (Placeholder)
                    </span>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-teal-700 tracking-wider block mb-1">
                        {ach.level}
                      </span>
                      <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition leading-snug">
                        {ach.title}
                      </h3>
                    </div>
                    <p className="text-xs text-slate-500 mt-4 flex items-center gap-1.5 pt-3 border-t border-teal-50">
                      <svg
                        className="w-3.5 h-3.5 text-teal-500 shrink-0"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                        />
                      </svg>
                      <span className="truncate">{ach.winner}</span>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        {/* END: SchoolAchievements */}

        {/* BEGIN: ExtracurricularActivities */}
        <section className="py-20 bg-teal-50/40" data-purpose="extracurriculars">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Pengembangan Diri
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Ekstrakurikuler</h2>
              <p className="text-sm text-slate-500 mt-2">
                Beragam kegiatan untuk mengembangkan bakat, minat, dan keterampilan siswa di luar jam pelajaran.
              </p>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-4 px-1">
              <span>← Geser untuk eksplorasi ekskul ({ekskulPage + 1}/2)</span>
              <div className="flex gap-1.5">
                <button
                  type="button"
                  onClick={handlePrevEkskul}
                  aria-label="Ekstrakurikuler sebelumnya"
                  className="w-7 h-7 rounded-full border border-teal-200 bg-white flex items-center justify-center text-teal-700 hover:border-teal-500 transition cursor-pointer"
                >
                  ←
                </button>
                <button
                  type="button"
                  onClick={handleNextEkskul}
                  aria-label="Ekstrakurikuler selanjutnya"
                  className="w-7 h-7 rounded-full border border-teal-200 bg-white flex items-center justify-center text-teal-700 hover:border-teal-500 transition cursor-pointer"
                >
                  →
                </button>
              </div>
            </div>
            {/* Horizontal Activity Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {visibleEkskul.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setModal({ type: 'extracurricular-detail', item })}
                  className="bg-white rounded-2xl p-5 border border-teal-100 text-center shadow-sm hover:shadow-md hover:border-teal-400 transition cursor-pointer group"
                >
                  <div className="text-3xl mb-2 group-hover:scale-110 transition">{item.emoji}</div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-teal-700 transition">
                    {item.name}
                  </h3>
                </div>
              ))}
            </div>
          </div>
        </section>
        {/* END: ExtracurricularActivities */}

        {/* BEGIN: PhotoGallerySection */}
        <section className="py-20 bg-white" data-purpose="photo-gallery" id="galeri">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14">
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Dokumentasi
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Galeri Kegiatan</h2>
              <p className="text-sm text-slate-500 mt-2">
                Momen-momen berharga dan kegiatan inspiratif dari seluruh civitas akademika.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {GALLERY_PHOTOS.map((photo) => (
                <div
                  key={photo.id}
                  onClick={() => setModal({ type: 'photo-detail', item: photo })}
                  className={`group relative rounded-2xl overflow-hidden aspect-[3/4] shadow-sm bg-gradient-to-br ${photo.gradientClass} border border-teal-200/80 flex flex-col justify-between p-5 cursor-pointer hover:shadow-md transition`}
                >
                  <div className="flex items-center justify-between text-teal-700">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-white/80 px-2 py-0.5 rounded">
                      {photo.badge}
                    </span>
                    <span className="text-[10px] font-mono opacity-60">{photo.aspect}</span>
                  </div>
                  <div className="my-auto text-center flex flex-col items-center">
                    <svg
                      className="w-12 h-12 text-teal-400 mb-2 group-hover:scale-110 transition duration-300"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth="1.5"
                      />
                    </svg>
                    <span className="text-xs font-semibold text-teal-900">Placeholder Foto Kegiatan</span>
                  </div>
                  <div className="bg-white/90 backdrop-blur rounded-xl p-3 shadow-sm border border-teal-100">
                    <h3 className="text-teal-950 font-bold text-xs">{photo.title}</h3>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <button
                type="button"
                onClick={() => setModal({ type: 'photo-all' })}
                className="inline-flex items-center gap-2 px-7 py-3 rounded-full text-white text-xs sm:text-sm font-semibold bg-teal-600 hover:bg-teal-700 shadow-md transition cursor-pointer"
              >
                Lihat Semua Galeri →
              </button>
            </div>
          </div>
        </section>
        {/* END: PhotoGallerySection */}

        {/* BEGIN: VideoShowcaseSection */}
        <section className="py-20 bg-teal-50/40 border-t border-teal-100" data-purpose="video-gallery">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14">
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Dokumentasi
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Galeri Video</h2>
              <p className="text-sm text-slate-500 mt-2">
                Dokumentasi kegiatan, prestasi, dan profil sekolah dalam format video interaktif.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {GALLERY_VIDEOS.map((vid) => (
                <div
                  key={vid.id}
                  onClick={() => setModal({ type: 'video-detail', item: vid })}
                  className="bg-white rounded-2xl border border-teal-100 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col group cursor-pointer"
                >
                  <div className="relative aspect-video bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 flex flex-col items-center justify-center p-3 text-center overflow-hidden">
                    <div className="absolute top-2 right-2 bg-teal-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                      Video
                    </div>
                    <div className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition mb-1">
                      <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                    <span className="text-[10px] text-teal-200 font-medium">
                      Thumbnail Placeholder (16:9)
                    </span>
                  </div>
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <h3 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-teal-700 transition line-clamp-2 mb-2">
                      {vid.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 line-clamp-2">{vid.description}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="text-center mt-12">
              <button
                type="button"
                onClick={() => setModal({ type: 'video-all' })}
                className="inline-flex items-center gap-2 px-7 py-3 rounded-full text-white text-xs sm:text-sm font-semibold bg-teal-600 hover:bg-teal-700 shadow-md transition cursor-pointer"
              >
                Lihat Semua Video →
              </button>
            </div>
          </div>
        </section>
        {/* END: VideoShowcaseSection */}

        {/* BEGIN: CallToActionBanner */}
        <section
          className="py-20 text-white cta-banner-bg relative overflow-hidden"
          data-purpose="cta-spmb-banner"
          id="spmb"
        >
          {/* Decorative circles */}
          <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-cyan-400/10 pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-teal-300/10 pointer-events-none" />
          <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center relative z-10">
            {/* Status Pill */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/20 text-teal-200 text-xs font-semibold mb-6">
              <span className="w-2 h-2 rounded-full bg-teal-300" />
              Pendaftaran Dibuka
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight mb-5 leading-tight text-balance">
              Bergabunglah dengan Keluarga Besar Kami
            </h2>
            <p className="text-sm sm:text-base text-teal-100 max-w-2xl mx-auto leading-relaxed mb-8">
              Daftarkan putra-putri Anda sekarang dan berikan mereka pendidikan terbaik untuk masa depan yang gemilang.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <button
                type="button"
                onClick={() => setModal({ type: 'spmb', initialTab: 'register' })}
                className="px-8 py-3.5 rounded-full text-slate-950 font-bold text-xs sm:text-sm bg-teal-300 hover:bg-teal-200 shadow-xl transition transform active:scale-95 cursor-pointer whitespace-nowrap"
              >
                Daftar SPMB Online →
              </button>
              <a
                className="px-8 py-3.5 rounded-full text-white font-semibold text-xs sm:text-sm bg-white/10 hover:bg-white/20 backdrop-blur border border-white/20 transition whitespace-nowrap"
                href="#kontak"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('#kontak');
                }}
              >
                Hubungi Kami
              </a>
            </div>
          </div>
        </section>
        {/* END: CallToActionBanner */}

        {/* BEGIN: TestimonialsSection */}
        <section className="py-20 bg-white" data-purpose="testimonials">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-14">
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Testimoni
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Apa Kata Mereka?</h2>
              <p className="text-sm text-slate-500 mt-2">
                Pendapat orang tua siswa dan alumni tentang pengalaman belajar di sekolah kami.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Testimonial 1 */}
              <div className="bg-white rounded-2xl p-6 sm:p-7 border border-teal-100 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex text-teal-500 text-sm mb-4">★★★★★</div>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic mb-6">
                    "Anak saya berkembang pesat sejak bersekolah di sini. Guru-gurunya sangat profesional dan penuh perhatian. Fasilitas sekolahnya juga sangat lengkap dan modern."
                  </p>
                </div>
                <div className="flex items-center gap-3 pt-4 border-t border-teal-100">
                  <div className="w-10 h-10 rounded-full bg-teal-700 text-white font-bold flex items-center justify-center text-xs">
                    H
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Hj. Siti Fatimah</h4>
                    <p className="text-[11px] text-slate-400">Wali Murid - 2025</p>
                  </div>
                </div>
              </div>
              {/* Testimonial 2 */}
              <div className="bg-white rounded-2xl p-6 sm:p-7 border border-teal-100 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex text-teal-500 text-sm mb-4">★★★★★</div>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic mb-6">
                    "Ilmu dan pengalaman yang saya dapatkan di sekolah ini sangat bermanfaat. Program bilingual-nya membantu saya lolos beasiswa di universitas luar negeri."
                  </p>
                </div>
                <div className="flex items-center gap-3 pt-4 border-t border-teal-100">
                  <div className="w-10 h-10 rounded-full bg-teal-700 text-white font-bold flex items-center justify-center text-xs">
                    A
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Ahmad Fauzi, S.T.</h4>
                    <p className="text-[11px] text-slate-400">Alumni - 2022</p>
                  </div>
                </div>
              </div>
              {/* Testimonial 3 */}
              <div className="bg-white rounded-2xl p-6 sm:p-7 border border-teal-100 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex text-teal-500 text-sm mb-4">★★★★★</div>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed italic mb-6">
                    "Saya sangat puas dengan kualitas pendidikan di sini. Anak saya tidak hanya pandai akademik, tapi juga memiliki akhlak yang baik dan percaya diri."
                  </p>
                </div>
                <div className="flex items-center gap-3 pt-4 border-t border-teal-100">
                  <div className="w-10 h-10 rounded-full bg-teal-700 text-white font-bold flex items-center justify-center text-xs">
                    D
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Dr. Rina Wulandari</h4>
                    <p className="text-[11px] text-slate-400">Wali Murid - 2024</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* END: TestimonialsSection */}
      </main>

      {/* BEGIN: MainFooter */}
      <footer
        className="bg-brand-darkTeal text-slate-300 pt-16 pb-8 border-t border-teal-950"
        data-purpose="site-footer"
        id="kontak"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-teal-800/40">
            {/* School Bio & Socials */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-full bg-teal-600 flex items-center justify-center text-white font-bold">
                  <svg className="w-5 h-5 text-teal-200" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                  </svg>
                </div>
                <span className="font-bold text-lg text-white">SMK Metland Cibitung</span>
              </div>
              <p className="text-xs text-teal-100/80 leading-relaxed max-w-sm mb-6">
                Membangun generasi cerdas, kreatif, dan berakhlak mulia untuk masa depan yang lebih baik melalui pendidikan berkualitas.
              </p>
              {/* Social Icons */}
              <div className="flex items-center gap-2.5">
                {[
                  { label: 'F', action: () => setModal({ type: 'news-all' }) },
                  { label: 'IG', action: () => setModal({ type: 'photo-all' }) },
                  { label: 'YT', action: () => setModal({ type: 'video-all' }) },
                  { label: 'X', action: () => setModal({ type: 'agenda-all' }) },
                ].map((soc) => (
                  <button
                    key={soc.label}
                    type="button"
                    onClick={soc.action}
                    className="w-8 h-8 rounded-full bg-teal-950 border border-teal-800/50 flex items-center justify-center text-teal-300 hover:text-white hover:bg-teal-800 transition text-xs font-bold cursor-pointer"
                  >
                    {soc.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Tautan Cepat</h4>
              <ul className="space-y-2.5 text-xs text-teal-100/80">
                <li>
                  <a
                    className="hover:text-white transition"
                    href="#profil"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('#profil');
                    }}
                  >
                    Profil Sekolah
                  </a>
                </li>
                <li>
                  <a
                    className="hover:text-white transition"
                    href="#guru"
                    onClick={(e) => {
                      e.preventDefault();
                      setModal({ type: 'guru-staff' });
                    }}
                  >
                    Guru &amp; Staff
                  </a>
                </li>
                <li>
                  <a
                    className="hover:text-white transition"
                    href="#galeri"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('#galeri');
                    }}
                  >
                    Galeri
                  </a>
                </li>
                <li>
                  <a
                    className="hover:text-white transition"
                    href="#kontak"
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection('#kontak');
                    }}
                  >
                    Hubungi Kami
                  </a>
                </li>
              </ul>
            </div>

            {/* Admissions Links */}
            <div>
              <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Pendaftaran</h4>
              <ul className="space-y-2.5 text-xs text-teal-100/80">
                <li>
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'spmb', initialTab: 'register' })}
                    className="hover:text-white transition cursor-pointer"
                  >
                    SPMB Online
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'spmb', initialTab: 'status' })}
                    className="hover:text-white transition cursor-pointer"
                  >
                    Cek Status Pendaftaran
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'spmb', initialTab: 'tuition' })}
                    className="hover:text-white transition cursor-pointer"
                  >
                    Biaya Pendidikan
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setModal({ type: 'spmb', initialTab: 'scholarship' })}
                    className="hover:text-white transition cursor-pointer"
                  >
                    Beasiswa Prestasi
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact Information */}
            <div>
              <h4 className="text-sm font-semibold text-white uppercase tracking-wider mb-4">Hubungi Kami</h4>
              <ul className="space-y-3 text-xs text-teal-100/80">
                <li className="flex items-start gap-2">
                  <span className="text-teal-400">📍</span>
                  <span>Jl. Pendidikan No. 123, Cibitung, Bekasi, Jawa Barat 17520</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-teal-400">📞</span>
                  <span>+62 811-2233-4455</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-teal-400">✉️</span>
                  <span>info@smkmetlandcibitung.sch.id</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Copyright Bottom Bar */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-teal-200/60 gap-3">
            <p>© 2026 SMK Metland Cibitung. Hak Cipta Dilindungi. | Powered by CMS Sekolah - AlangAlang Dev</p>
            <div className="flex gap-4">
              <button
                type="button"
                onClick={() => setModal({ type: 'legal', section: 'privacy' })}
                className="hover:underline cursor-pointer"
              >
                Kebijakan Privasi
              </button>
              <button
                type="button"
                onClick={() => setModal({ type: 'legal', section: 'terms' })}
                className="hover:underline cursor-pointer"
              >
                Syarat &amp; Ketentuan
              </button>
            </div>
          </div>
        </div>
      </footer>
      {/* END: MainFooter */}

      {/* Interactive Modals */}
      <PortalModals
        modal={modal}
        onClose={() => setModal({ type: 'none' })}
        onSelectModal={(nextModal) => setModal(nextModal)}
        newsList={NEWS_ITEMS}
        agendaList={AGENDA_ITEMS}
        achievementsList={ACHIEVEMENT_ITEMS}
        photosList={GALLERY_PHOTOS}
        videosList={GALLERY_VIDEOS}
        teachersList={TEACHERS_AND_STAFF}
        spmbApplications={spmbApplications}
        onAddSpmbApplication={handleAddSpmbApplication}
      />
    </div>
  );
}
