import React, { useState } from 'react';
import {
  NewsItem,
  AgendaItem,
  ProgramItem,
  AchievementItem,
  ExtracurricularItem,
  GalleryPhotoItem,
  GalleryVideoItem,
  TeacherStaffItem,
  SpmbApplication,
} from '../data/schoolData';

export type ActiveModal =
  | { type: 'none' }
  | { type: 'news-detail'; item: NewsItem }
  | { type: 'news-all' }
  | { type: 'agenda-detail'; item: AgendaItem }
  | { type: 'agenda-all' }
  | { type: 'program-detail'; item: ProgramItem }
  | { type: 'achievement-detail'; item: AchievementItem }
  | { type: 'achievement-all' }
  | { type: 'extracurricular-detail'; item: ExtracurricularItem }
  | { type: 'photo-detail'; item: GalleryPhotoItem }
  | { type: 'photo-all' }
  | { type: 'video-detail'; item: GalleryVideoItem }
  | { type: 'video-all' }
  | { type: 'guru-staff' }
  | { type: 'spmb'; initialTab?: 'register' | 'status' | 'tuition' | 'scholarship' }
  | { type: 'legal'; section: 'privacy' | 'terms' };

interface PortalModalsProps {
  modal: ActiveModal;
  onClose: () => void;
  onSelectModal: (modal: ActiveModal) => void;
  newsList: NewsItem[];
  agendaList: AgendaItem[];
  achievementsList: AchievementItem[];
  photosList: GalleryPhotoItem[];
  videosList: GalleryVideoItem[];
  teachersList: TeacherStaffItem[];
  spmbApplications: SpmbApplication[];
  onAddSpmbApplication: (app: SpmbApplication) => void;
}

export const PortalModals: React.FC<PortalModalsProps> = ({
  modal,
  onClose,
  onSelectModal,
  newsList,
  agendaList,
  achievementsList,
  photosList,
  videosList,
  teachersList,
  spmbApplications,
  onAddSpmbApplication,
}) => {
  const [newsCategoryFilter, setNewsCategoryFilter] = useState<string>('Semua');
  const [achCategoryFilter, setAchCategoryFilter] = useState<string>('Semua');
  const [isPlayingVideo, setIsPlayingVideo] = useState<boolean>(false);

  // SPMB state
  const [spmbTab, setSpmbTab] = useState<'register' | 'status' | 'tuition' | 'scholarship'>('register');
  const [fullName, setFullName] = useState('');
  const [nisn, setNisn] = useState('');
  const [originSchool, setOriginSchool] = useState('');
  const [program, setProgram] = useState('Program Bilingual');
  const [parentName, setParentName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  const [formError, setFormError] = useState('');
  const [submittedApp, setSubmittedApp] = useState<SpmbApplication | null>(null);
  const [statusQuery, setStatusQuery] = useState('');

  React.useEffect(() => {
    if (modal.type === 'spmb' && modal.initialTab) {
      setSpmbTab(modal.initialTab);
    }
    if (modal.type === 'video-detail') {
      setIsPlayingVideo(false);
    }
  }, [modal]);

  if (modal.type === 'none') return null;

  const handleSpmbSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !nisn.trim() || !originSchool.trim() || !parentName.trim() || !phone.trim()) {
      setFormError('Mohon lengkapi seluruh kolom wajib (Nama, NISN, Sekolah Asal, Nama Orang Tua, dan No. WhatsApp).');
      return;
    }
    setFormError('');
    const randomCode = Math.floor(1100 + Math.random() * 8800);
    const newApp: SpmbApplication = {
      regNumber: `SPMB-2026-${randomCode}`,
      fullName: fullName.trim(),
      nisn: nisn.trim(),
      originSchool: originSchool.trim(),
      program,
      parentName: parentName.trim(),
      phone: phone.trim(),
      email: email.trim() || 'siswa@smkmetlandcibitung.sch.id',
      address: address.trim() || 'Cibitung, Bekasi, Jawa Barat',
      createdAt: new Date().toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
      status: 'Terverifikasi - Jadwal Tes Tersedia',
    };
    onAddSpmbApplication(newApp);
    setSubmittedApp(newApp);
    setFullName('');
    setNisn('');
    setOriginSchool('');
    setParentName('');
    setPhone('');
    setEmail('');
    setAddress('');
  };

  const filteredStatusApps = spmbApplications.filter((app) => {
    if (!statusQuery.trim()) return true;
    const q = statusQuery.toLowerCase();
    return (
      app.regNumber.toLowerCase().includes(q) ||
      app.fullName.toLowerCase().includes(q) ||
      app.nisn.toLowerCase().includes(q)
    );
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-sm p-4 overflow-y-auto"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div
        className="relative w-full max-w-3xl bg-white rounded-3xl border border-teal-100 shadow-2xl overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-teal-50/60 border-b border-teal-100">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-teal-600 text-white flex items-center justify-center font-bold text-xs">
              SMK
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700 block">
                SMK Metland Cibitung
              </span>
              <span className="text-[11px] text-slate-500">Excellence with Character</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white border border-teal-200 text-slate-600 hover:text-teal-700 hover:bg-teal-50 flex items-center justify-center transition text-sm font-bold"
            aria-label="Tutup modal"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* 1. NEWS DETAIL */}
          {modal.type === 'news-detail' && (
            <div>
              <div className="relative h-56 rounded-2xl bg-teal-50/70 border border-teal-100 flex flex-col items-center justify-center mb-6 overflow-hidden">
                <span
                  className={`absolute top-4 left-4 ${modal.item.categoryBadgeBg} text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm`}
                >
                  {modal.item.category}
                </span>
                <svg
                  className="w-16 h-16 text-teal-300 mb-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Z"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="1.5"
                  />
                </svg>
                <span className="text-xs font-medium text-teal-700/70">Thumbnail Berita (16:9)</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-3">
                <span>{modal.item.date}</span>
                <span>·</span>
                <span>{modal.item.author}</span>
                <span>·</span>
                <span>{modal.item.readTime}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug mb-4">
                {modal.item.title}
              </h2>
              <div className="space-y-4 text-sm text-slate-600 leading-relaxed">
                {modal.item.content.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
              <div className="mt-8 pt-5 border-t border-teal-100 flex items-center justify-between">
                <button
                  onClick={() => onSelectModal({ type: 'news-all' })}
                  className="text-xs font-semibold text-teal-700 hover:underline"
                >
                  ← Kembali ke Semua Berita
                </button>
                <button
                  onClick={() => onSelectModal({ type: 'spmb', initialTab: 'register' })}
                  className="px-4 py-2 rounded-full text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 transition"
                >
                  Daftar SPMB Online →
                </button>
              </div>
            </div>
          )}

          {/* 2. ALL NEWS ARCHIVE */}
          {modal.type === 'news-all' && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block">
                    Indeks Informasi
                  </span>
                  <h2 className="text-2xl font-extrabold text-slate-900">Semua Berita Sekolah</h2>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {['Semua', 'Prestasi', 'Kegiatan Siswa', 'Pengumuman', 'Akademik'].map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setNewsCategoryFilter(cat)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold transition ${
                        newsCategoryFilter === cat
                          ? 'bg-teal-600 text-white'
                          : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {newsList
                  .filter((n) => newsCategoryFilter === 'Semua' || n.category === newsCategoryFilter)
                  .map((item) => (
                    <article
                      key={item.id}
                      onClick={() => onSelectModal({ type: 'news-detail', item })}
                      className="bg-white rounded-2xl border border-teal-100 overflow-hidden shadow-sm hover:shadow-md transition flex flex-col cursor-pointer group"
                    >
                      <div
                        className={`relative h-36 ${item.cardBgTint} border-b border-teal-100 flex flex-col items-center justify-center`}
                      >
                        <span
                          className={`absolute top-3 left-3 ${item.categoryBadgeBg} text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider`}
                        >
                          {item.category}
                        </span>
                        <span className="text-[11px] font-medium text-teal-700/70">Thumbnail Berita (16:9)</span>
                      </div>
                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[11px] text-slate-400 block mb-1">{item.date}</span>
                          <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 transition mb-2">
                            {item.title}
                          </h3>
                          <p className="text-xs text-slate-600 line-clamp-2 mb-3">{item.summary}</p>
                        </div>
                        <span className="text-xs font-semibold text-teal-700 group-hover:underline">
                          Baca Selengkapnya →
                        </span>
                      </div>
                    </article>
                  ))}
              </div>
            </div>
          )}

          {/* 3. AGENDA DETAIL & ALL AGENDA */}
          {(modal.type === 'agenda-detail' || modal.type === 'agenda-all') && (
            <div>
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Kalender Akademik & Kegiatan
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 mb-6">Agenda SMK Metland Cibitung</h2>
              <div className="space-y-4">
                {(modal.type === 'agenda-detail' ? [modal.item] : agendaList).map((ag) => (
                  <div
                    key={ag.id}
                    className="p-4 rounded-2xl bg-teal-50/50 border border-teal-100 flex items-start gap-4"
                  >
                    <div className="w-14 h-14 rounded-xl bg-teal-700 text-white flex flex-col items-center justify-center flex-shrink-0 shadow-sm">
                      <span className="text-lg font-bold leading-none">{ag.day}</span>
                      <span className="text-[10px] uppercase font-semibold mt-0.5">{ag.month}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className="text-sm sm:text-base font-bold text-slate-900">{ag.title}</h3>
                        <span className="text-xs font-medium text-teal-700">{ag.fullDate}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        Lokasi: <strong className="text-slate-800">{ag.location}</strong> · Waktu:{' '}
                        <strong className="text-slate-800">{ag.time}</strong>
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">Penyelenggara: {ag.organizer}</p>
                      <p className="text-xs sm:text-sm text-slate-700 mt-2.5 leading-relaxed">{ag.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              {modal.type === 'agenda-detail' && (
                <div className="mt-6 pt-4 border-t border-teal-100">
                  <button
                    onClick={() => onSelectModal({ type: 'agenda-all' })}
                    className="text-xs font-semibold text-teal-700 hover:underline"
                  >
                    Lihat Seluruh Jadwal Agenda →
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 4. PROGRAM UNGGULAN DETAIL */}
          {modal.type === 'program-detail' && (
            <div>
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Keunggulan Kurikulum
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 mb-2">{modal.item.title}</h2>
              <p className="text-sm text-slate-600 leading-relaxed mb-6">{modal.item.shortDesc}</p>
              <div className="bg-teal-50/50 rounded-2xl p-5 border border-teal-100 space-y-4 mb-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-2">
                    Keunggulan & Fasilitas Program
                  </h3>
                  <ul className="space-y-2 text-xs sm:text-sm text-slate-700">
                    {modal.item.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-teal-600 font-bold">✓</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="pt-3 border-t border-teal-100">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-1">
                    Fokus Pembelajaran
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-700">{modal.item.curriculumFocus}</p>
                </div>
                <div className="pt-3 border-t border-teal-100">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-1">
                    Prospek Lulusan & Karir
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-700">{modal.item.careerProspects}</p>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  onClick={() => {
                    setProgram(modal.item.title);
                    onSelectModal({ type: 'spmb', initialTab: 'register' });
                  }}
                  className="px-5 py-2.5 rounded-full text-xs font-bold bg-teal-600 text-white hover:bg-teal-700 transition"
                >
                  Daftar Program Ini di SPMB Online →
                </button>
              </div>
            </div>
          )}

          {/* 5. ACHIEVEMENTS DETAIL & ALL */}
          {(modal.type === 'achievement-detail' || modal.type === 'achievement-all') && (
            <div>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block">
                    Achievement Center
                  </span>
                  <h2 className="text-2xl font-extrabold text-slate-900">Prestasi Membanggakan</h2>
                </div>
                {modal.type === 'achievement-all' && (
                  <div className="flex flex-wrap gap-1.5">
                    {['Semua', 'Siswa', 'Guru', 'Sekolah', 'Ekstrakurikuler'].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setAchCategoryFilter(cat)}
                        className={`px-3 py-1.5 rounded-full text-xs font-semibold transition ${
                          achCategoryFilter === cat
                            ? 'bg-teal-600 text-white'
                            : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {(modal.type === 'achievement-detail'
                  ? [modal.item]
                  : achievementsList.filter(
                      (a) => achCategoryFilter === 'Semua' || a.category === achCategoryFilter
                    )
                ).map((ach) => (
                  <div
                    key={ach.id}
                    className="rounded-2xl border border-teal-100 bg-white p-5 shadow-sm flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                        <span className="font-bold text-teal-700 uppercase tracking-wider">{ach.level}</span>
                        <span>
                          {ach.category} · {ach.year}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900 mb-2">{ach.title}</h3>
                      <p className="text-xs text-slate-600 leading-relaxed mb-4">{ach.description}</p>
                    </div>
                    <div className="pt-3 border-t border-teal-50 text-xs font-semibold text-teal-800">
                      Peraih: {ach.winner}
                    </div>
                  </div>
                ))}
              </div>
              {modal.type === 'achievement-detail' && (
                <div className="mt-6 pt-4 border-t border-teal-100">
                  <button
                    onClick={() => onSelectModal({ type: 'achievement-all' })}
                    className="text-xs font-semibold text-teal-700 hover:underline"
                  >
                    Lihat Semua Prestasi →
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 6. EXTRACURRICULAR DETAIL */}
          {modal.type === 'extracurricular-detail' && (
            <div>
              <div className="flex items-center gap-4 mb-5">
                <div className="w-16 h-16 rounded-2xl bg-teal-50 border border-teal-100 flex items-center justify-center text-4xl">
                  {modal.item.emoji}
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
                    Ekstrakurikuler · {modal.item.category}
                  </span>
                  <h2 className="text-2xl font-extrabold text-slate-900">{modal.item.name}</h2>
                </div>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed mb-5">{modal.item.description}</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-teal-50/50 p-4 rounded-2xl border border-teal-100 text-xs mb-5">
                <div>
                  <span className="text-slate-400 block mb-0.5">Jadwal Latihan</span>
                  <strong className="text-slate-800">{modal.item.schedule}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Lokasi Kegiatan</span>
                  <strong className="text-slate-800">{modal.item.location}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Pembina / Pelatih</span>
                  <strong className="text-slate-800">{modal.item.coach}</strong>
                </div>
              </div>
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-2">
                  Catatan Prestasi & Kegiatan
                </h3>
                <ul className="space-y-1.5 text-xs text-slate-600">
                  {modal.item.achievements.map((ac, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="text-teal-600 font-bold">•</span>
                      <span>{ac}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          {/* 7. PHOTO GALLERY LIGHTBOX & ALL */}
          {(modal.type === 'photo-detail' || modal.type === 'photo-all') && (
            <div>
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Dokumentasi Civitas Akademika
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 mb-5">Galeri Kegiatan Sekolah</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {(modal.type === 'photo-detail' ? [modal.item] : photosList).map((ph) => (
                  <div
                    key={ph.id}
                    className="rounded-2xl border border-teal-200 overflow-hidden bg-white shadow-sm flex flex-col"
                  >
                    <div
                      className={`h-56 bg-gradient-to-br ${ph.gradientClass} p-5 flex flex-col justify-between border-b border-teal-100`}
                    >
                      <div className="flex items-center justify-between text-teal-700 text-xs font-bold">
                        <span>{ph.badge}</span>
                        <span className="font-mono opacity-70">{ph.aspect}</span>
                      </div>
                      <div className="my-auto text-center flex flex-col items-center">
                        <svg
                          className="w-12 h-12 text-teal-400 mb-2"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Z"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="1.5"
                          />
                        </svg>
                        <span className="text-xs font-semibold text-teal-900">Placeholder Foto Kegiatan</span>
                      </div>
                      <div className="text-xs text-teal-800 font-medium">
                        {ph.category} · {ph.date}
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="text-base font-bold text-slate-900 mb-1">{ph.title}</h3>
                      <p className="text-xs text-slate-600 leading-relaxed">{ph.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              {modal.type === 'photo-detail' && (
                <div className="mt-6 pt-4 border-t border-teal-100">
                  <button
                    onClick={() => onSelectModal({ type: 'photo-all' })}
                    className="text-xs font-semibold text-teal-700 hover:underline"
                  >
                    Lihat Semua Galeri Foto →
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 8. VIDEO SHOWCASE PLAYER & ALL */}
          {(modal.type === 'video-detail' || modal.type === 'video-all') && (
            <div>
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Dokumentasi Multimedia
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 mb-5">Galeri Video SMK Metland Cibitung</h2>
              {modal.type === 'video-detail' ? (
                <div>
                  <div className="relative aspect-video rounded-2xl bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 flex flex-col items-center justify-center p-6 text-center overflow-hidden mb-5 border border-teal-800">
                    {!isPlayingVideo ? (
                      <>
                        <button
                          onClick={() => setIsPlayingVideo(true)}
                          className="w-16 h-16 rounded-full bg-teal-500 hover:bg-teal-400 text-white flex items-center justify-center shadow-lg transition transform hover:scale-105 mb-3"
                        >
                          <svg className="w-8 h-8 fill-current ml-1" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </button>
                        <span className="text-xs font-semibold text-teal-200">
                          Klik untuk Memutar Pratinjau Video ({modal.item.duration})
                        </span>
                        <span className="text-[11px] text-teal-400/80 mt-1">
                          Thumbnail Placeholder (16:9) · {modal.item.category}
                        </span>
                      </>
                    ) : (
                      <div className="w-full h-full flex flex-col justify-between p-4 text-left">
                        <div className="flex items-center justify-between text-xs text-teal-300">
                          <span>▶ Sedang Memutar: {modal.item.title}</span>
                          <span className="font-mono">{modal.item.duration}</span>
                        </div>
                        <div className="my-auto text-center">
                          <div className="inline-block px-4 py-2 rounded-xl bg-teal-900/60 border border-teal-500/40 text-teal-100 text-xs mb-2">
                            Simulasi Pemutar Video Dokumentasi Sekolah (1080p HD)
                          </div>
                          <p className="text-xs text-teal-200/90 max-w-md mx-auto">{modal.item.description}</p>
                        </div>
                        <div className="space-y-2">
                          <div className="w-full h-1.5 rounded-full bg-teal-950 overflow-hidden">
                            <div className="w-2/5 h-full bg-teal-400 rounded-full" />
                          </div>
                          <div className="flex justify-between text-[11px] text-teal-300 font-mono">
                            <span>01:38 / {modal.item.duration}</span>
                            <button
                              onClick={() => setIsPlayingVideo(false)}
                              className="text-teal-200 hover:text-white underline"
                            >
                              Berhenti
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">{modal.item.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-600 mb-4">{modal.item.description}</p>
                  <div className="bg-teal-50/50 rounded-xl p-4 border border-teal-100">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-teal-800 mb-2">
                      Sorotan Isi Video
                    </h4>
                    <ul className="space-y-1 text-xs text-slate-700">
                      {modal.item.highlights.map((h, i) => (
                        <li key={i}>• {h}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-5 pt-4 border-t border-teal-100">
                    <button
                      onClick={() => onSelectModal({ type: 'video-all' })}
                      className="text-xs font-semibold text-teal-700 hover:underline"
                    >
                      ← Lihat Semua Koleksi Video
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {videosList.map((vid) => (
                    <div
                      key={vid.id}
                      onClick={() => onSelectModal({ type: 'video-detail', item: vid })}
                      className="rounded-2xl border border-teal-100 overflow-hidden shadow-sm hover:shadow-md transition cursor-pointer group bg-white"
                    >
                      <div className="relative aspect-video bg-gradient-to-br from-slate-900 via-teal-950 to-slate-900 flex flex-col items-center justify-center p-3 text-center">
                        <div className="w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition mb-1">
                          <svg className="w-5 h-5 fill-current ml-0.5" viewBox="0 0 24 24">
                            <path d="M8 5v14l11-7z" />
                          </svg>
                        </div>
                        <span className="text-[10px] text-teal-200 font-medium">
                          {vid.duration} · {vid.category}
                        </span>
                      </div>
                      <div className="p-4">
                        <h3 className="text-sm font-bold text-slate-900 group-hover:text-teal-700 mb-1">
                          {vid.title}
                        </h3>
                        <p className="text-xs text-slate-500 line-clamp-2">{vid.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* 9. GURU & STAFF DIRECTORY */}
          {modal.type === 'guru-staff' && (
            <div>
              <span className="text-xs font-bold tracking-widest text-teal-700 uppercase block mb-1">
                Civitas Akademika
              </span>
              <h2 className="text-2xl font-extrabold text-slate-900 mb-2">Direktori Guru & Tenaga Pendidik</h2>
              <p className="text-xs sm:text-sm text-slate-600 mb-6">
                Didukung oleh lebih dari 85 pendidik profesional dan bersertifikat yang berdedikasi membimbing siswa SMK Metland Cibitung.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {teachersList.map((t) => (
                  <div
                    key={t.id}
                    className="p-4 rounded-2xl border border-teal-100 bg-teal-50/30 flex items-start gap-3.5"
                  >
                    <div className="w-12 h-12 rounded-xl bg-teal-700 text-white font-bold flex items-center justify-center flex-shrink-0 text-sm">
                      {t.name
                        .split(' ')
                        .slice(0, 2)
                        .map((n) => n[0])
                        .join('')}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{t.name}</h3>
                      <p className="text-xs font-semibold text-teal-700">{t.role}</p>
                      <p className="text-[11px] text-slate-500 mt-1">
                        {t.department} · {t.education}
                      </p>
                      <p className="text-[11px] text-slate-600 italic mt-2">"{t.quote}"</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 10. SPMB SUITE MODAL (Registration, Status Check, Tuition, Scholarship) */}
          {modal.type === 'spmb' && (
            <div>
              <div className="flex flex-wrap gap-2 pb-4 mb-6 border-b border-teal-100">
                {[
                  { id: 'register', label: 'Daftar SPMB Online' },
                  { id: 'status', label: 'Cek Status Pendaftaran' },
                  { id: 'tuition', label: 'Biaya Pendidikan' },
                  { id: 'scholarship', label: 'Beasiswa Prestasi' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setSpmbTab(tab.id as 'register' | 'status' | 'tuition' | 'scholarship');
                      setSubmittedApp(null);
                    }}
                    className={`px-4 py-2 rounded-full text-xs font-semibold transition ${
                      spmbTab === tab.id
                        ? 'bg-teal-600 text-white shadow-sm'
                        : 'bg-teal-50 text-teal-800 hover:bg-teal-100'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {spmbTab === 'register' && (
                <div>
                  {submittedApp ? (
                    <div className="bg-teal-50 border border-teal-200 rounded-2xl p-6 text-center space-y-4">
                      <div className="w-12 h-12 rounded-full bg-teal-600 text-white flex items-center justify-center mx-auto font-bold text-lg">
                        ✓
                      </div>
                      <h3 className="text-xl font-extrabold text-slate-900">
                        Pendaftaran SPMB Berhasil Diterima!
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                        Simpan Nomor Registrasi di bawah ini untuk mengecek status seleksi pada menu{' '}
                        <strong>Cek Status Pendaftaran</strong>.
                      </p>
                      <div className="bg-white rounded-xl p-4 border border-teal-200 max-w-md mx-auto text-left text-xs space-y-1.5">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Nomor Registrasi:</span>
                          <strong className="font-mono text-teal-700 text-sm">{submittedApp.regNumber}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Nama Calon Siswa:</span>
                          <strong className="text-slate-900">{submittedApp.fullName}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">NISN:</span>
                          <strong className="font-mono text-slate-900">{submittedApp.nisn}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Program Pilihan:</span>
                          <strong className="text-teal-700">{submittedApp.program}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Status Awal:</span>
                          <strong className="text-teal-700">{submittedApp.status}</strong>
                        </div>
                      </div>
                      <div className="flex justify-center gap-3 pt-2">
                        <button
                          onClick={() => {
                            setStatusQuery(submittedApp.regNumber);
                            setSpmbTab('status');
                          }}
                          className="px-5 py-2.5 rounded-full text-xs font-bold bg-teal-600 text-white hover:bg-teal-700 transition"
                        >
                          Cek Status Sekarang →
                        </button>
                        <button
                          onClick={() => setSubmittedApp(null)}
                          className="px-4 py-2.5 rounded-full text-xs font-semibold border border-teal-200 text-teal-800 hover:bg-white transition"
                        >
                          Daftarkan Siswa Lain
                        </button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleSpmbSubmit} className="space-y-4">
                      <div>
                        <h3 className="text-lg font-bold text-slate-900">
                          Formulir Penerimaan Murid Baru (SPMB) Tahun Ajaran 2026/2027
                        </h3>
                        <p className="text-xs text-slate-500">
                          Isi data calon peserta didik dengan benar untuk mendapatkan Nomor Registrasi ujian seleksi.
                        </p>
                      </div>
                      {formError && (
                        <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
                          {formError}
                        </div>
                      )}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Nama Lengkap Calon Siswa *
                          </label>
                          <input
                            type="text"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            placeholder="Contoh: Muhammad Farhan"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            NISN (10 Digit) *
                          </label>
                          <input
                            type="text"
                            value={nisn}
                            onChange={(e) => setNisn(e.target.value)}
                            placeholder="Contoh: 0098123456"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Sekolah Asal (SMP/MTs) *
                          </label>
                          <input
                            type="text"
                            value={originSchool}
                            onChange={(e) => setOriginSchool(e.target.value)}
                            placeholder="Contoh: SMP Negeri 1 Cibitung"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Pilihan Program Unggulan *
                          </label>
                          <select
                            value={program}
                            onChange={(e) => setProgram(e.target.value)}
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none bg-white"
                          >
                            <option value="Program Bilingual">Program Bilingual</option>
                            <option value="Tahfidz Al-Qur'an">Tahfidz Al-Qur'an</option>
                            <option value="STEM & Robotik">STEM & Robotik</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Nama Orang Tua / Wali *
                          </label>
                          <input
                            type="text"
                            value={parentName}
                            onChange={(e) => setParentName(e.target.value)}
                            placeholder="Nama Ayah / Ibu / Wali"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Nomor WhatsApp Aktif *
                          </label>
                          <input
                            type="tel"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            placeholder="Contoh: 081234567890"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Email (Opsional)
                          </label>
                          <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="nama@email.com"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-slate-700 mb-1">
                            Domisili / Alamat Singkat
                          </label>
                          <input
                            type="text"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            placeholder="Kecamatan / Kota"
                            className="w-full rounded-xl border border-teal-200 px-3.5 py-2 text-xs focus:border-teal-600 focus:outline-none"
                          />
                        </div>
                      </div>
                      <div className="pt-2 flex items-center justify-end gap-3">
                        <button
                          type="button"
                          onClick={onClose}
                          className="px-4 py-2.5 rounded-full text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          className="px-6 py-2.5 rounded-full text-xs font-bold bg-teal-600 text-white hover:bg-teal-700 shadow-md transition"
                        >
                          Kirim Pendaftaran SPMB →
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}

              {spmbTab === 'status' && (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Cek Status Pendaftaran SPMB 2026</h3>
                    <p className="text-xs text-slate-500">
                      Masukkan Nomor Registrasi (misal: <code className="text-teal-700">SPMB-2026-1042</code>), NISN, atau Nama Siswa.
                    </p>
                  </div>
                  <input
                    type="text"
                    value={statusQuery}
                    onChange={(e) => setStatusQuery(e.target.value)}
                    placeholder="Cari Nomor Registrasi, NISN, atau Nama..."
                    className="w-full rounded-xl border border-teal-200 px-4 py-2.5 text-xs focus:border-teal-600 focus:outline-none"
                  />
                  <div className="space-y-3">
                    {filteredStatusApps.map((app) => (
                      <div
                        key={app.regNumber}
                        className="p-4 rounded-2xl border border-teal-100 bg-teal-50/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div>
                          <div className="flex items-center gap-2 text-xs">
                            <strong className="font-mono text-teal-800">{app.regNumber}</strong>
                            <span>·</span>
                            <span className="text-slate-500">NISN: {app.nisn}</span>
                          </div>
                          <h4 className="text-sm font-bold text-slate-900 mt-0.5">{app.fullName}</h4>
                          <p className="text-xs text-slate-600">
                            Asal: {app.originSchool} · Pilihan: <strong>{app.program}</strong>
                          </p>
                        </div>
                        <div className="text-left sm:text-right">
                          <span className="inline-block text-xs font-bold text-teal-700 bg-white px-3 py-1 rounded-full border border-teal-200">
                            {app.status}
                          </span>
                          <span className="block text-[11px] text-slate-400 mt-1">
                            Terdaftar: {app.createdAt}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {spmbTab === 'tuition' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-slate-900">Informasi Biaya Pendidikan T.A. 2026/2027</h3>
                  <p className="text-xs text-slate-600">
                    SMK Metland Cibitung menyediakan skema pembiayaan transparan dan terjangkau dengan fasilitas laboratorium berstandar industri.
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                    <div className="p-4 rounded-2xl border border-teal-100 bg-teal-50/40">
                      <span className="text-teal-700 font-bold uppercase block mb-1">Gelombang 1 (Early Bird)</span>
                      <div className="text-xl font-extrabold text-slate-900 tabular-nums mb-1">Diskon 25% DSP</div>
                      <p className="text-slate-600">Berlaku untuk pendaftaran Mei – Juni 2026 termasuk seragam & modul digital.</p>
                    </div>
                    <div className="p-4 rounded-2xl border border-teal-100 bg-teal-50/40">
                      <span className="text-teal-700 font-bold uppercase block mb-1">SPP Bulanan</span>
                      <div className="text-xl font-extrabold text-slate-900 tabular-nums mb-1">Rp 650.000 / bln</div>
                      <p className="text-slate-600">Sudah mencakup praktikum laboratorium robotik, bilingual, & ekstrakurikuler.</p>
                    </div>
                    <div className="p-4 rounded-2xl border border-teal-100 bg-teal-50/40">
                      <span className="text-teal-700 font-bold uppercase block mb-1">Cicilan Ringan</span>
                      <div className="text-xl font-extrabold text-slate-900 tabular-nums mb-1">Hingga 6x Tahap</div>
                      <p className="text-slate-600">Kemudahan angsuran Dana Sumbangan Pendidikan (DSP) selama semester pertama.</p>
                    </div>
                  </div>
                </div>
              )}

              {spmbTab === 'scholarship' && (
                <div className="space-y-4">
                  <h3 className="text-lg font-bold text-slate-900">Program Beasiswa Prestasi & Tahfidz</h3>
                  <div className="space-y-3 text-xs">
                    <div className="p-4 rounded-2xl border border-teal-100 bg-white">
                      <h4 className="font-bold text-slate-900 text-sm mb-1">1. Beasiswa Prestasi Akademik & OSN</h4>
                      <p className="text-slate-600">
                        Bebas DSP 100% dan potongan SPP hingga 50% bagi peringkat 1–3 paralel SMP/MTs atau peraih juara kompetisi tingkat Kabupaten/Provinsi/Nasional.
                      </p>
                    </div>
                    <div className="p-4 rounded-2xl border border-teal-100 bg-white">
                      <h4 className="font-bold text-slate-900 text-sm mb-1">2. Beasiswa Tahfidz Al-Qur'an</h4>
                      <p className="text-slate-600">
                        Apresiasi khusus bebas biaya SPP hingga 12 bulan bagi calon siswa dengan hafalan minimal 5 Juz Al-Qur'an mutqin.
                      </p>
                    </div>
                    <div className="p-4 rounded-2xl border border-teal-100 bg-white">
                      <h4 className="font-bold text-slate-900 text-sm mb-1">3. Beasiswa Mitra Industri</h4>
                      <p className="text-slate-600">
                        Dukungan biaya pendidikan dan ikatan dinas magang bagi siswa berprestasi pada jurusan STEM & Robotik.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 11. PRIVACY & TERMS */}
          {modal.type === 'legal' && (
            <div className="space-y-4">
              <h2 className="text-xl font-extrabold text-slate-900">
                {modal.section === 'privacy' ? 'Kebijakan Privasi' : 'Syarat & Ketentuan Layanan Portal'}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                {modal.section === 'privacy'
                  ? 'SMK Metland Cibitung berkomitmen melindungi privasi data pribadi calon siswa, orang tua/wali murid, dan pengunjung portal resmi sekolah. Data pendaftaran SPMB Online hanya digunakan untuk keperluan verifikasi administrasi akademik dan komunikasi resmi panitia penerimaan siswa baru.'
                  : 'Seluruh informasi akademik, jadwal agenda, dan pengumuman pada portal resmi SMK Metland Cibitung dikelola oleh Tim Humas & Kurikulum Sekolah. Calon peserta didik wajib memastikan keaslian dokumen NISN dan rapor saat mengikuti proses verifikasi SPMB Online.'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
